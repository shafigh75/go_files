from fastapi import FastAPI, Depends, Query, Path, HTTPException, Form, File, UploadFile, BackgroundTasks, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from typing import Optional, List
from enum import Enum

app = FastAPI()

# Enum for query parameter
class ItemType(str, Enum):
    book = "book"
    toy = "toy"

# Pydantic model for request body
class Item(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    tax: Optional[float] = None

class LogMessage(BaseModel):
    message: str

# Dependency
def common_parameters(q: Optional[str] = None, skip: int = 0, limit: int = 10):
    return {"q": q, "skip": skip, "limit": limit}

# Basic route with path and query parameters
@app.get("/items/{item_id}")
async def read_item(item_id: int, q: Optional[str] = None):
    return {"item_id": item_id, "q": q}

# Request body and dependency injection
@app.post("/items/")
async def create_item(item: Item, commons: dict = Depends(common_parameters)):
    return {"item": item, "commons": commons}

# Form data
@app.post("/login/")
async def login(username: str = Form(...), password: str = Form(...)):
    return {"username": username}

# File upload
@app.post("/uploadfile/")
async def upload_file(file: UploadFile = File(...)):
    return {"filename": file.filename}

# Background task
def write_log(message: str):
    with open("log.txt", "a") as log:
        log.write(message)

@app.post("/log/")
async def create_log(background_tasks: BackgroundTasks, message: LogMessage):
    background_tasks.add_task(write_log, message.message)
    return {"message": "Log created"}

# WebSocket
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)

manager = ConnectionManager()

@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: int):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await manager.send_personal_message(f"You wrote: {data}", websocket)
            await manager.broadcast(f"Client {client_id} says: {data}")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        await manager.broadcast(f"Client {client_id} left the chat")

# Handling errors and responses
@app.get("/error/")
async def raise_error():
    raise HTTPException(status_code=404, detail="Item not found")

@app.get("/custom_response/")
async def custom_response():
    return {"message": "Custom response"}

# Running the application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)

