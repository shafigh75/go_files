curl -X 'GET' \
  'http://127.0.0.1:8000/items/1?q=searchterm' \
  -H 'accept: application/json'

curl -X 'POST' \
  'http://127.0.0.1:8000/items/' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "name": "Sample Item",
  "description": "This is a sample item",
  "price": 25.5,
  "tax": 1.5
}'


curl -X 'POST' \
  'http://127.0.0.1:8000/login/' \
  -H 'accept: application/json' \
  -F 'username=user1' \
  -F 'password=pass123'


curl -X 'POST' \
  'http://127.0.0.1:8000/uploadfile/' \
  -H 'accept: application/json' \
  -F 'file=@/path/to/your/file.txt'


curl -X 'POST' \
  'http://127.0.0.1:8000/log/' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{"message": "This is a log message"}'


wscat -c ws://127.0.0.1:8000/ws/123


curl -X 'GET' \
  'http://127.0.0.1:8000/error/' \
  -H 'accept: application/json'


curl -X 'GET' \
  'http://127.0.0.1:8000/custom_response/' \
  -H 'accept: application/json'

