import json
import os
import requests
from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

app = FastAPI()

# Mount static to serve our generated images and any custom assets.
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


def generate_image(prompt: str) -> bool:
    url = "https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-dev"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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",
    }
    payload = {"inputs": prompt}
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        os.makedirs("static", exist_ok=True)
        with open("static/img.png", "wb") as out_file:
            out_file.write(response.content)
        return True
    else:
        print("Image API error:", response.status_code, response.text)
        return False


def chat_completion(messages: list) -> dict:
    """
    Sends the conversation messages to the chat model API and returns the result.
    """
    url = "https://api-inference.huggingface.co/models/google/gemma-2-2b-it/v1/chat/completions"
    headers = {
        "Authorization": "Bearer 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",
        "Content-Type": "application/json",
    }
    json_data = {
        "model": "google/gemma-2-2b-it",
        "messages": messages,
        "max_tokens": 500,
        "stream": False
    }
    response = requests.post(url, headers=headers, json=json_data, verify=False)
    if response.status_code == 200:
        try:
            data = response.json()
            return data
        except Exception as e:
            print("Error parsing chat completion response:", e)
            return {"error": "Response parsing error"}
    else:
        print("Chat API error:", response.status_code, response.text)
        return {"error": f"Chat API error {response.status_code}"}


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    # Render the main page with default tab as chat.
    return templates.TemplateResponse("index.html", {
        "request": request,
        "active_tab": "chat",
        "chat_history": [],
        "chat_response": None,
        "image": None,
        "error": None,
    })


@app.post("/chat", response_class=HTMLResponse)
async def chat_post(request: Request, prompt: str = Form(...), history: str = Form("[]")):
    try:
        chat_history = json.loads(history)
    except Exception:
        chat_history = []

    # Append the user's message.
    chat_history.append({"role": "user", "content": prompt})

    result = chat_completion(chat_history)
    if "error" not in result:
        # Assuming the response returns choices with a message field.
        bot_message = result.get("choices", [{}])[0].get("message", {}).get("content", "")
        chat_history.append({"role": "assistant", "content": bot_message})
        chat_response = bot_message
        error_message = None
    else:
        chat_response = None
        error_message = result.get("error", "Unknown error occurred.")

    return templates.TemplateResponse("index.html", {
        "request": request,
        "active_tab": "chat",
        "chat_history": chat_history,
        "chat_response": chat_response,
        "image": None,
        "error": error_message,
    })


@app.post("/image", response_class=HTMLResponse)
async def image_post(request: Request, prompt: str = Form(...)):
    success = generate_image(prompt)
    if success:
        image_url = "/static/img.png"
        error_message = None
    else:
        image_url = None
        error_message = "Image generation failed. Please try again."
    return templates.TemplateResponse("index.html", {
        "request": request,
        "active_tab": "image",
        "chat_history": [],
        "chat_response": None,
        "image": image_url,
        "error": error_message,
    })


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="5.252.216.154", port=8000, log_level="info")

