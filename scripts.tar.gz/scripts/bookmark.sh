#! /bin/bash

xdotool key super+KP_Enter

sleep 0.5
zenity --question --title="bookmarks manager" --text "what do you want to do?" --ok-label="see bookmarks" --cancel-label="bookmarks action"
case $? in
  0)
    # opening bookmarks
    tmux new  'cat /home/mohammad-shafighishahri/bookmarks \
      | fzf-tmux -p -w 35%  --reverse --border --prompt "enter something to search from bookmarks ->  " --header "---- bookmarks ----" \
      | xargs -I {} firefox {}'
    ;;
  1)
    # bookmarks action 
    zenity --question --title="bookmarks manager" --text "what is on your mind?" --ok-label="add bookmarks" --cancel-label="delete bookmarks"
    case $? in
      0) 
        # adding bookmark
        zenity --entry --width 600 --text="add a new bookmark" >> /home/mohammad-shafighishahri/bookmarks ;;
      1)
        # removing bookmark
        tmux new  'cat /home/mohammad-shafighishahri/bookmarks \
          | fzf-tmux -p -w 35%  --reverse --border --prompt "enter something to search from bookmarks ->  " --header "---- bookmarks ----" \
          > tmp'
        prompt=$(cat tmp)
        echo $prompt
        sed -i "\?$prompt?d" /home/mohammad-shafighishahri/bookmarks
        rm tmp
        ;;
      *)
         echo "invalid option";;
    esac 
    ;;
  *)
    echo "invalid option";;
esac

