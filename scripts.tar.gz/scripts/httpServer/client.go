package main

import (
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"sync"
	"time"
)

func makeRequest(url string, headers map[string]string, wg *sync.WaitGroup) {
	defer wg.Done()

	// Seed the random number generator with the current time
	rand.Seed(time.Now().UnixNano())

	// Generate a random number between 1 and 100
	randomNumber := rand.Intn(100) + 1
	time.Sleep(time.Millisecond * randomNumber)

	client := &http.Client{}
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		fmt.Println("Error creating request:", err)
		return
	}

	for key, value := range headers {
		if key == "host" {
			req.Host = value
		}
		req.Header.Set(key, value)
	}

	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("Error making request:", err)
		return
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)

	fmt.Printf("Response from %s: %s\n %+v", url, resp.Status, string(body))
}

func main() {
	url := "http://127.0.0.1:4001/service/loadbalance"
	headers := map[string]string{
		"gateway-system": "api_gateway",
		"host":           "gateway-v3-dev.apipart.ir",
	}

	// Number of concurrent requests
	concurrentRequests := 5000
	var wg sync.WaitGroup
	wg.Add(concurrentRequests)

	for i := 0; i < concurrentRequests; i++ {
		go makeRequest(url, headers, &wg)
	}

	wg.Wait()
	fmt.Println("All requests completed.")
}
