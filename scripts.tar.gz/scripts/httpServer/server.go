package main

import (
	"fmt"
	"net/http"
	"os"
	"strconv"
	"sync/atomic"
)

type Server struct {
	port    any
	request uint64
}

func main() {
	// Check if a port number is provided as a command line argument
	if len(os.Args) != 2 {
		fmt.Println("Usage: go run main.go <port>")
		os.Exit(1)
	}

	// Parse the port number from the command line argument
	port, err := strconv.Atoi(os.Args[1])
	if err != nil {
		fmt.Println("Invalid port number:", os.Args[1])
		os.Exit(1)
	}

	S := Server{port: port}
	// Define the endpoint handler
	http.HandleFunc("/", S.echoPortHandler)

	// Specify the port to listen on
	addr := fmt.Sprintf(":%d", port)

	// Start the HTTP server
	fmt.Printf("Server listening on port %d...\n", port)
	err = http.ListenAndServe(addr, nil)
	if err != nil {
		fmt.Printf("Error starting the server: %v\n", err)
	}
}

// The handler for the /echoport endpoint
func (server *Server) echoPortHandler(w http.ResponseWriter, r *http.Request) {
	atomic.AddUint64(&server.request, 1)
	fmt.Println("one incoming request ...")
	// Write the port number in the response
	// response := fmt.Sprintf("request for this Port %d\n", server.port)
	response := fmt.Sprintf("request for this Port %d\nTotal incoming requests: %d\n", server.port, atomic.LoadUint64(&server.request))
	w.Write([]byte(response))
}
