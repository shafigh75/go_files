#!/bin/bash
read -p "Please enter your hostname: " VM_HOSTNAME
USERNAME="mohammad.shafighishahri"
PASSWORD="NpeTkMHP6qA3gHq"
DARKOOB_TOKEN=$(curl -s 'https://darkoob.partdp.ir/service/darkoob/login' \
    --header 'Content-Type: application/json' \
    --data "{\"username\": \"$USERNAME\", \"password\": \"$PASSWORD\"}" |
    jq .data.token | cut -c 2- | rev | cut -c 2- | rev)
VM_ACCESS=$(curl -s "https://darkoob.partdp.ir//service/darkoob/checkServer?hostname=$VM_HOSTNAME" \
    --header "Authorization: $DARKOOB_TOKEN")
sleep 3
VM_INFO=$(curl -s "https://darkoob.partdp.ir/service/darkoob/server?page_size=10&page_number=1&name=$VM_HOSTNAME" \
    --header "authorization: $DARKOOB_TOKEN" | jq .data.serversInfo)

if [ "$VM_INFO" == "[]" ]; then
    echo "شما در این سرور نام‌کاربری ندارید"
else
    echo "دسترسی با موفقیت ایجاد شد"
    echo $VM_INFO | jq
fi
