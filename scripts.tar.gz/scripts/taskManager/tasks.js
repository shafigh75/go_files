import inquirer from 'inquirer'
import fs from 'fs'
const tasksFilePath = 'tasks.json';

// Read tasks from JSON file
const readTasks = () => {
  try {
    const tasksData = fs.readFileSync(tasksFilePath);
    return JSON.parse(tasksData);
  } catch (error) {
    return [];
  }
};

// Write tasks to JSON file
const writeTasks = (tasks) => {
  fs.writeFileSync(tasksFilePath, JSON.stringify(tasks, null, 2));
};

// Function to add a new task
const addTask = async () => {
  const tasks = readTasks();
  const { task } = await inquirer.prompt([
    {
      type: 'input',
      name: 'task',
      message: 'Enter task:',
    },
  ]);
  tasks.push({ id: tasks.length + 1, task });
  writeTasks(tasks);
  console.log('Task added successfully!');
};

// Function to display all tasks
const listTasks = () => {
  const tasks = readTasks();
  console.log('Tasks:');
  tasks.forEach(({ id, task }) => console.log(`${id}. ${task}`));
};

const deleteTasks = async () => {
  listTasks();
  const tasks = readTasks();
  const { task } = await inquirer.prompt([
    {
      type: 'input',
      name: 'task',
      message: 'Enter task to delete:',
    },
  ]);
  const idExists = tasks.some(myTask => myTask.id == task);
  let taskFilter = tasks.filter(outTask => outTask.id == task);
  let indexToRemove = idExists ? taskFilter.id - 1 : 0;
  if (indexToRemove === 0) {
    console.error("invalid task number!!");
  } else {
  tasks.splice(indexToRemove, 1);
  writeTasks(tasks);
  console.log("task deleted sucsessfuly");
  }

}
// Function to start the application
const main = async () => {
  console.log("\n###################")
  const { choice } = await inquirer.prompt([
    {
      type: 'list',
      name: 'choice',
      message: 'Choose an action:',
      choices: ['Add Task', 'List Tasks', 'Delete Tasks', 'Exit'],
    },
  ]);

  switch (choice) {
    case 'Add Task':
      console.clear();
      console.log("\n###################")
      await addTask();
      break;
    case 'List Tasks':
      console.clear();
      console.log("\n###################")
      listTasks();
      break;
    case 'Delete Tasks':
      console.clear();
      console.log("\n###################")
      await deleteTasks();
      break;
    case 'Exit':
      console.log('Goodbye!');
      process.exit();
  }

  main(); // Repeat main function
};

// Start the application
main();

