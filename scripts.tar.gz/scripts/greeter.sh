# Add this function to your .bashrc or .bash_profile
geeky_greet() {
    local RED="\033[0;31m"
    local GREEN="\033[0;32m"
    local YELLOW="\033[1;33m"
    local BLUE="\033[1;34m"
    local PURPLE="\033[0;35m"
    local CYAN="\033[0;36m"
    local WHITE="\033[1;37m"
    local NO_COLOR="\033[0m"

    # Clear the terminal
    clear

    # Print ASCII art
    echo -e "${RED}"
    echo "      .--."
    echo "     |o_o |"
    echo "     |:_/ |"
    echo "    //   \\ \\"
    echo "   (|     | )"
    echo "  /'\\_   _/\`\\"
    echo "  \\___)=(___/"
    echo -e "${NO_COLOR}"

    # Print a geeky greeting
    echo -e "${CYAN}Initialization sequence activated... Welcome, $USER.${NO_COLOR}"

    # Print the date in ISO 8601 format
    echo -e "${YELLOW}Current Stardate: $(date -I)${NO_COLOR}"

    # Print system uptime and load
    echo -e "${GREEN}System status: $(uptime -p), Load: $(cat /proc/loadavg | awk '{print $1, $2, $3}')${NO_COLOR}"

    # Print memory and disk usage
    echo -e "${BLUE}Memory check: $(free -h | grep Mem | awk '{print $3 "/" $2}')${NO_COLOR}"
    echo -e "${PURPLE}Disk status: $(df -h | grep '/$' | awk '{print $3 "/" $2 " used (" $5 ")"}')${NO_COLOR}"

    # Print the current directory using an alias
    echo -e "${WHITE}Launching in directory:${NO_COLOR} $(pwd)"
}

# Call the function geeky_greet when a new shell starts
geeky_greet

