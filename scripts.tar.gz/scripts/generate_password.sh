#!/bin/bash

# Function to generate a random password
generate_password() {
    tr -dc 'a-zA-Z0-9' < /dev/urandom | fold -w 14 | head -n 1 | xargs -I {} echo {}!
}

# Generate a random password
password=$(generate_password)

echo $password
