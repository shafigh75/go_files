#!/bin/bash

# Set the file path of the keyring file
keyring_file="path/to/your/keyring/file"

# Check if the file exists
if [ ! -f "$keyring_file" ]; then
    echo "Keyring file not found!"
    exit 1
fi

# Parse the keyring file and extract display names and secrets
display_names=($(grep -oP '(?<=display-name=).*' "$keyring_file"))
secrets=($(grep -oP '(?<=secret=).*' "$keyring_file"))

# Output the display names and secrets
for ((i=0; i<${#display_names[@]}; i++)); do
    echo "Display Name: ${display_names[i]}, Secret: ${secrets[i]}"
done

