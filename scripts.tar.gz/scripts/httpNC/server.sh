#!/bin/bash

# Define the port number
PORT=8080

# Start the HTTP server
while true; do
  # Listen for incoming connections and serve HTTP response
  {
    echo -ne "HTTP/1.1 200 OK\r\n"
    echo -ne "Content-Type: text/html\r\n"
    echo -ne "\r\n"
    echo -ne "<html><head><title>Notification Server</title></head><body><h1>Notification Server</h1><p>This is a notification server.</p></body></html>\r\n"
  } | nc -l -p $PORT -q 0| (
    # Check if the request is for the /notify endpoint and trigger the notification
    while read -r line; do
      if [[ "$line" == *"GET /notify"* ]]; then
        notify-send "Notification" "You've been notified!"
      fi
    done
  )
done

