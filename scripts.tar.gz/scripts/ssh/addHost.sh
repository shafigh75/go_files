#!/bin/bash

# Check if all three arguments are provided
if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <hostname> <ip_address> <username>"
    exit 1
fi

# Assign input values to variables
hostname="$1"
ip_address="$2"
username="$3"

# Add host configuration to the ~/.ssh/config file
echo -e "Host $hostname\n\tHostname $ip_address\n\tUser $username\n\tSetEnv TERM=xterm" >> ~/.ssh/config

echo "Host configuration added successfully for $hostname."

