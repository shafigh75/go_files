#!/bin/bash

destination_directory_out="/var/log/devops/req-barjavand/out"
destination_directory_err="/var/log/devops/req-barjavand/error"
src_out_dir="/home/devops"
src_err_dir="/home/devops/errors"
for i in {44..1}; do
    file_out="barjavand-out.log.$i"
    if [ -f "$src_out_dir/$file_out" ]; then
        echo "$src_out_dir/$file_out" "$destination_directory_out"
    fi
    file_err="barjavand-error.log.$i"
    if [ -f "$src_err_dir/$file_err" ]; then
        echo "$src_err_dir/$file_err" "$destination_directory_err"
    fi
   # sleep 15
    if [ "$i" -eq 1 ]; then
	echo     "$src_out_dir/barjavand-out.log" $destination_directory_out
	echo     "$src_err_dir/barjavand-error.log" $destination_directory_err
    fi
done

