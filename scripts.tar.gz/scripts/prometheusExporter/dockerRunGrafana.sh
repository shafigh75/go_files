# start grafana
docker run -d -p 3000:3000 --name=grafana \
  --volume grafana-storage:/var/lib/grafana \
  --add-host=host.docker.internal:host-gateway \
  grafana/grafana-enterprise

