package main

import (
    "net/http"
    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
    "time"
    "encoding/json"
    "math/rand"
)

var (
    customMetric = prometheus.NewGauge(prometheus.GaugeOpts{
        Name: "custom_metric",
        Help: "This is a custom metric",
    })
)

type req struct {
   Number float64 `json:"number"`
}

func init() {
    prometheus.MustRegister(customMetric)
}

func main() {
    // Seed the random number generator with current time
    rand.Seed(time.Now().UnixNano())
    http.Handle("/metrics", promhttp.Handler())
    http.HandleFunc("/num", metricHandler)
    go generateMetrics() // Function to generate sample metrics
    http.ListenAndServe("0.0.0.0:8080", nil)
}

func generateMetrics() {
    for {
        // Generate a random integer between 0 and 100
        randomNum := rand.Float64() // Generates a random number between 0 and 100
        // Your code to collect and set metric values
        customMetric.Set(randomNum * 100) // Example value, replace with actual logic
        time.Sleep(15 * time.Second) // Sleep for some time before updating metrics
    }
}

func metricHandler(w http.ResponseWriter, r *http.Request){
  var Request req      
  _ = json.NewDecoder(r.Body).Decode(&Request)
  num := Request.Number
  generate(num)
  w.Write([]byte("written to prometheus"))
}

func generate(number float64){
        customMetric.Set(number) // Example value, replace with actual logic
}
