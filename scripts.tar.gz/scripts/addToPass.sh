#!/bin/bash

# Define the input file
input_file="path/to/your/input/file"

# Check if the input file exists
if [ ! -f "$input_file" ]; then
    echo "Input file not found!"
    exit 1
fi

# Create the servers directory if it doesn't exist
pass_dir="~/.password-store/servers"
mkdir -p "$pass_dir"

# Loop through each line in the input file
while IFS= read -r line; do
    # Extract display name and secret from the line
    display_name=$(echo "$line" | awk -F', ' '{print $1}' | cut -d':' -f2)
    secret=$(echo "$line" | awk -F', ' '{print $2}' | cut -d':' -f2)
    
    # Add entry to pass
    pass insert -m servers/"$display_name" <<< "$secret"
done < "$input_file"

