import etcd3

# Connect to etcd
client = etcd3.client(host='127.0.0.1', port=2379)

# Set a key-value pair
key = '/message'
value = 'Hello world'
client.put(key, value)
print(f"Set key {key} with value {value}")

# Get the value of the key
result = client.get(key)
if result[0] is not None:
    print(f"Got value {result[0].decode('utf-8')} for key {key}")
else:
    print(f"Key {key} not found")

# Close the connection
client.close()




