import etcd3
import socket

# Connect to etcd
etcd = etcd3.client(host='127.0.0.1', port=2379)

# Service details
service_name = 'auth-service'
service_address = socket.gethostbyname(socket.gethostname()) + ':5000'

# Register service with etcd
etcd.put(f'/services/{service_name}', service_address)
print(f"Registered {service_name} at {service_address}")





import etcd3

# Connect to etcd
etcd = etcd3.client(host='127.0.0.1', port=2379)

# Discover auth-service
auth_service_key = '/services/auth-service'
auth_service_address, _ = etcd.get(auth_service_key)

if auth_service_address:
    print(f"Discovered auth-service at {auth_service_address.decode('utf-8')}")
else:
    print("auth-service not found")






import etcd3

# Connect to etcd
etcd = etcd3.client(host='127.0.0.1', port=2379)

# Callback function to handle key changes
def watch_callback(event):
    print(f"Watch event: {event}")

# Watch for changes in auth-service registration
watch_id = etcd.add_watch_callback('/services/auth-service', watch_callback)

# Run indefinitely to keep watching
try:
    while True:
        pass
except KeyboardInterrupt:
    # Remove watch on exit
    etcd.cancel_watch(watch_id)
    print("Stopped watching")

