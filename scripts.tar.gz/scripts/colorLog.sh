#!/bin/bash

# Function to print colored messages with datetime
print_colored_message() {
    local message="$1"
    local color_code="$2"
    local datetime=$(date +"%Y-%m-%d %H:%M:%S")

    # Define color codes
    case "$color_code" in
        "error")
            color="\e[31m"  # Red text
            ;;
        "info")
            color="\e[94m"  # Blue text
            ;;
        "success")
            color="\e[32m"  # Green text
            ;;
        *)
            color="\e[39m"  # Default color (white)
            ;;
    esac

    # Print datetime, message, and color
    echo -e "${color}[${datetime}] ${message}\e[0m"
}

# Example usage
print_colored_message "This is an error message" "error"
print_colored_message "This is an info message" "info"
print_colored_message "This is a success message" "success"
print_colored_message "This is a default message with no specific color"

# You can add more customizations as needed

