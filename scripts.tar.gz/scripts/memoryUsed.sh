#!/bin/bash

# Function to calculate total memory for a process and its sub-processes

pid=$1
spid=$(ps -e --format pid,ppid | awk -v main_pid=$pid '$2 == main_pid { print $1 }')
spidMem=$(pmap -x $spid | tail -n1 | awk '{sum = $3 + $4 + $5;print sum}')
pidMem=$(pmap -x $pid | tail -n1 | awk '{sum = $3 + $4 + $5; print sum}')
total=$(( pidMem + spidMem ))
python3 -c "print($total/1000000,' GB')"
