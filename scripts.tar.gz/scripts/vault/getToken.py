import requests
import json

# Define the URL and payload
url = 'https://vault.partdp.ir/v1/auth/ldap/login/mohammad.shafighishahri'
payload = {"password": "@#$_Mohammad_123_$#@"}

# Make the POST request
response = requests.post(url, json=payload)

# Check if the request was successful
if response.status_code == 200:
    # Parse the JSON response
    response_data = response.json()
    
    # Extract the client_token
    client_token = response_data['auth']['client_token']
    print("Client Token:", client_token)
else:
    print(f"Request failed with status code {response.status_code}")
    print("Response:", response.text)


