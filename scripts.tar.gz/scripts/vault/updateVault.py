import requests
import json
import subprocess

def getListFromVault():
# Step 1: Get the token
# Define the URL and payload for the token request
    token_url = 'https://vault.partdp.ir/v1/auth/ldap/login/mohammad.shafighishahri'
    token_payload = {"password": "@#$_Mohammad_123_$#@"}

# Make the POST request to get the token
    token_response = requests.post(token_url, json=token_payload)

# Check if the request was successful
    if token_response.status_code == 200:
        # Parse the JSON response
        token_data = token_response.json()
        
        # Extract the client_token
        client_token = token_data['auth']['client_token']
        
        # Step 2: Use the token to make the second request
        # Define the URL and headers for the second request
        second_url = 'https://vault.partdp.ir/v1/part/metadata/share/mohammad.shafighishahri/?list=true'
        headers = {'X-Vault-Token': client_token}
        
        # Make the GET request using the token
        second_response = requests.get(second_url, headers=headers)
        
        # Check if the request was successful
        if second_response.status_code == 200:
            # Parse the JSON response
            second_data = second_response.json()
            keyList = second_data["data"]["keys"]
            return keyList
        else:
            print(f"Second request failed with status code {second_response.status_code}")
            print("Second Response:", second_response.text)
    else:
        print(f"Token request failed with status code {token_response.status_code}")
        print("Token Response:", token_response.text)


def getListFromSystem():

# Define the command
    command = "ls /home/mohammad-shafighishahri/.password-store/servers | sed 's/.gpg//'"

# Run the command
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

# Get the output and errors (if any)
    output = result.stdout
    errors = result.stderr

# return the output
    if errors:
        print("Errors:\n", errors)
    return output


def getKey(server):
    token_url = 'https://vault.partdp.ir/v1/auth/ldap/login/mohammad.shafighishahri'
    token_payload = {"password": "@#$_Mohammad_123_$#@"}

# Make the POST request to get the token
    token_response = requests.post(token_url, json=token_payload)

# Check if the request was successful
    if token_response.status_code == 200:
        # Parse the JSON response
        token_data = token_response.json()
        
        # Extract the client_token
        client_token = token_data['auth']['client_token']
        
        # Step 2: Use the token to make the second request
        # Define the URL and headers for the second request
        second_url = f'https://vault.partdp.ir/v1/part/data/share/mohammad.shafighishahri/{server}?version=1'
        headers = {'X-Vault-Token': client_token}
        
        # Make the GET request using the token
        second_response = requests.get(second_url, headers=headers)
        
        # Check if the request was successful
        if second_response.status_code == 200:
            # Parse the JSON response
            second_data = second_response.json()
            keyData = second_data["data"]["data"]
            return keyData
        else:
            print(f"Second request failed with status code {second_response.status_code}")
            print("Second Response:", second_response.text)
    else:
        print(f"Token request failed with status code {token_response.status_code}")
        print("Token Response:", token_response.text)


def getDataFromPass(server):
# Define the command
    command = f"pass servers/{server}"

# Run the command
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

# Get the output and errors (if any)
    output = result.stdout
    errors = result.stderr

# return the output
    if errors:
        print("Errors:\n", errors)
    return output


def getToken():
    token_url = 'https://vault.partdp.ir/v1/auth/ldap/login/mohammad.shafighishahri'
    token_payload = {"password": "@#$_Mohammad_123_$#@"}

# Make the POST request to get the token
    token_response = requests.post(token_url, json=token_payload)

# Check if the request was successful
    if token_response.status_code == 200:
        # Parse the JSON response
        token_data = token_response.json()
        
        # Extract the client_token
        client_token = token_data['auth']['client_token']
        return client_token
    



def updateVault(mydata,version,token,server):

# Define the URL and headers
    url = f'https://vault.partdp.ir/v1/part/data/share/mohammad.shafighishahri/{server}'
    headers = {
        'X-Vault-Token': f'{token}',
        'Content-Type': 'application/json'
    }

# Define the data payload
    data = {
        "data":  mydata,
        "options": {
            "cas": version
        }
    }

# Make the PUT request
    response = requests.put(url, headers=headers, json=data)

# Check if the request was successful
    if response.status_code == 200:
        print("Request was successful")
        print("Response:", response.json())
    else:
        print(f"Request failed with status code {response.status_code}")
        print("Response:", response.text)



vaultKeyList = getListFromVault()
systemKeyList = getListFromSystem().splitlines()

# identical items in both lists
finalList = [item for item in systemKeyList if item in vaultKeyList]
for server in finalList:
    data = getKey(server)
    passwd = getDataFromPass(server).strip()
    data["password"] = passwd
    token = getToken()
    updateVault(data,1,token,server)
