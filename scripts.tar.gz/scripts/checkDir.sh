#! /bin/bash
# simple bash script to check
#

files=$(cat files.txt)

# check if directory or file or not existing:

for file in $files 
do 
  echo "checking => $file "
if [ -d $file ]
then
  echo "DIR"
elif [ -f $file ] 
then
  echo "file"
else 
  echo "no such file or dir"
fi
done

