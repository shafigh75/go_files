#!/bin/bash

# Ollama Setup Script - Created by mohammadrasoul

GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Handle Ctrl+C
trap 'echo -e "\n${RED}❌ Setup interrupted by user. Exiting...${NC}"; exit 1' SIGINT

echo -e "${BLUE}----------------------------------------------${NC}"
echo -e "${GREEN}Welcome 👋 to the Ollama Setup Wizard!${NC}"
echo -e "${BLUE}----------------------------------------------${NC}"
echo ""

# Step 1: Install or update Ollama
read -p "Do you want to install or update Ollama? [y/N]: " install_choice
install_choice=${install_choice:-n}
ollama_installed=true

if [[ "$install_choice" =~ ^[Yy]$ ]]; then
    echo -e "${GREEN}Installing/Updating Ollama...${NC}"
    if ! curl -fsSL https://ollama.com/install.sh | sh; then
        echo -e "${RED}❌ Failed to install or update Ollama.${NC}"
        ollama_installed=false
    fi
else
    echo -e "${GREEN}Skipping Ollama installation/update.${NC}"
fi

# Step 2: Pull model
model_pulled=false
if command -v ollama &> /dev/null; then
    echo ""
    read -p "Which model do you want to pull? (default: gemma3n:e4b): " model_name
    model_name=${model_name:-gemma3n:e4b}

    echo -e "${GREEN}Pulling model: $model_name...${NC}"
    if ollama pull "$model_name"; then
        model_pulled=true
    else
        echo -e "${RED}❌ Failed to pull model: $model_name${NC}"
    fi
else
    echo -e "${RED}⚠️ Ollama command not found. Skipping model pull.${NC}"
fi

# Final Result
echo ""
echo -e "${BLUE}----------------------------------------------${NC}"
if [[ "$ollama_installed" == true && "$model_pulled" == true ]]; then
    echo -e "${GREEN}✅ Setup completed successfully.${NC}"
else
    echo -e "${RED}⚠️ Setup encountered one or more errors.${NC}"
fi
echo -e "${BLUE}-- Script by mohammadrasoul 💻 --${NC}"
