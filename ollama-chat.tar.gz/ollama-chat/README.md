# Ollama Chat Interface

A beautiful, minimal chat interface for interacting with locally running Ollama models.

## Features

- Clean, modern UI with gradient backgrounds
- Real-time chat with your local AI model
- Streaming responses with typing effect
- Proper markdown rendering for responses
- Responsive design that works on mobile and desktop
- Typing indicators for better UX

## Prerequisites

- Go 1.21 or higher
- Ollama with a running model (default configured for `gemma3n:e4b`)

## Installation

1. Clone this repository
2. Navigate to the project directory
3. Install Go dependencies:
   ```bash
   go mod tidy
   ```

## Usage

1. Make sure your Ollama model is running:
   ```bash
   ollama run gemma3n:e4b
   ```

2. Start the Go server:
   ```bash
   go run main.go
   ```

3. Open your browser and navigate to `http://localhost:8080`

4. Start chatting with your AI model!

## Project Structure

```
.
├── main.go              # Go backend server
├── go.mod               # Go module dependencies
├── go.sum               # Go module checksums
├── README.md            # This file
└── frontend/
    ├── index.html       # Main HTML file
    ├── static/
    │   ├── style.css    # Styling
    │   └── script.js    # Frontend logic
```

## Customization

### Changing the Model

To use a different Ollama model, you can either:

1. Change the default model in `main.go`:
   ```go
   // Set default model if not provided
   if req.Model == "" {
       req.Model = "your-model-name"
   }
   ```

2. Or specify the model in the frontend JavaScript in `frontend/static/script.js`:
   ```javascript
   body: JSON.stringify({
       model: "your-model-name",
       messages: chatMessages,
       stream: false
   })
   ```

### Styling

Modify `frontend/static/style.css` to change the look and feel of the chat interface.

## API Endpoints

- `GET /` - Serve the chat interface
- `POST /api/chat` - Send a message to the Ollama model

## Direct API Usage

You can also communicate directly with the backend using curl for automation tasks:

### Streaming Response
```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma3n:e4b",
    "messages": [
      {
        "role": "user",
        "content": "Hello, how are you?"
      }
    ],
    "stream": true
  }'
```

### Non-streaming Response
```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma3n:e4b",
    "messages": [
      {
        "role": "user",
        "content": "Hello, how are you?"
      }
    ],
    "stream": false
  }'
```

## Dependencies

- [Gin Web Framework](https://github.com/gin-gonic/gin) - For the Go backend
- [Marked](https://github.com/markedjs/marked) - For markdown rendering
- [Font Awesome](https://fontawesome.com/) - For icons

## License

This project is open source and available under the MIT License.
