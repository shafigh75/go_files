// DOM elements
const chatHistory = document.getElementById('chatHistory');
const chatForm = document.getElementById('chatForm');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const typingIndicator = document.getElementById('typingIndicator');

// Chat state
let chatMessages = [
    {
        role: "assistant",
        content: "Hello! I'm your local AI assistant powered by Ollama. How can I help you today?"
    }
];

// Initialize marked for markdown rendering
marked.setOptions({
    breaks: true,
    gfm: true
});

// Function to add a message to the chat
function addMessageToChat(role, content) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(`${role}-message`);
    
    const messageHeader = document.createElement('div');
    messageHeader.classList.add('message-header');
    
    const icon = document.createElement('i');
    icon.className = role === 'user' ? 'fas fa-user' : 'fas fa-robot';
    
    const strong = document.createElement('strong');
    strong.textContent = role === 'user' ? 'You' : 'Assistant';
    
    messageHeader.appendChild(icon);
    messageHeader.appendChild(strong);
    
    const messageContent = document.createElement('div');
    messageContent.classList.add('message-content');
    messageContent.innerHTML = marked.parse(content);
    
    messageDiv.appendChild(messageHeader);
    messageDiv.appendChild(messageContent);
    
    chatHistory.appendChild(messageDiv);
    
    // Scroll to bottom
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// Function to show typing indicator
function showTypingIndicator() {
    typingIndicator.style.display = 'flex';
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// Function to hide typing indicator
function hideTypingIndicator() {
    typingIndicator.style.display = 'none';
}

// Function to send message to backend with streaming
async function sendMessageToBackend(message, messageElement) {
    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: "gemma3n:e4b",
                messages: chatMessages,
                stream: true
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        // Get the message content element
        const messageContent = messageElement.querySelector('.message-content');
        
        // Process the streaming response
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let assistantMessage = '';
        
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            buffer += decoder.decode(value, { stream: true });
            
            // Process complete JSON objects
            const lines = buffer.split('\n');
            buffer = lines.pop(); // Keep the last incomplete line in the buffer
            
            for (const line of lines) {
                if (line.trim() === '') continue;
                
                try {
                    const data = JSON.parse(line);
                    if (data.message && data.message.content) {
                        assistantMessage += data.message.content;
                        // Update the message content with markdown rendering
                        messageContent.innerHTML = marked.parse(assistantMessage);
                        // Scroll to bottom as content grows
                        chatHistory.scrollTop = chatHistory.scrollHeight;
                    }
                } catch (e) {
                    console.error('Error parsing JSON:', e);
                }
            }
        }
        
        return assistantMessage;
    } catch (error) {
        console.error('Error sending message:', error);
        return "Sorry, I encountered an error while processing your request.";
    }
}

// Function to handle form submission
async function handleSubmit(event) {
    event.preventDefault();
    
    const message = messageInput.value.trim();
    if (!message) return;
    
    // Add user message to chat
    chatMessages.push({ role: 'user', content: message });
    addMessageToChat('user', message);
    
    // Clear input
    messageInput.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Create a new message element for the assistant response
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', 'assistant-message');
    
    const messageHeader = document.createElement('div');
    messageHeader.classList.add('message-header');
    
    const icon = document.createElement('i');
    icon.className = 'fas fa-robot';
    
    const strong = document.createElement('strong');
    strong.textContent = 'Assistant';
    
    messageHeader.appendChild(icon);
    messageHeader.appendChild(strong);
    
    const messageContent = document.createElement('div');
    messageContent.classList.add('message-content');
    
    messageDiv.appendChild(messageHeader);
    messageDiv.appendChild(messageContent);
    
    chatHistory.appendChild(messageDiv);
    
    // Scroll to bottom
    chatHistory.scrollTop = chatHistory.scrollHeight;
    
    // Send message to backend and get response
    const response = await sendMessageToBackend(message, messageDiv);
    
    // Hide typing indicator
    hideTypingIndicator();
    
    // Add assistant message to chat history
    chatMessages.push({ role: 'assistant', content: response });
}

// Event listeners
chatForm.addEventListener('submit', handleSubmit);

// Allow sending message with Enter key (but Shift+Enter for new line)
messageInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        handleSubmit(new Event('submit'));
    }
});

// Initial scroll to bottom
chatHistory.scrollTop = chatHistory.scrollHeight;
