package main

import (
    "context"
    "fmt"
    "io"
    "log"
    "time"

    "google.golang.org/grpc"
    pb "example/examplep" // Update with your actual path
)

func main() {
    conn, err := grpc.Dial("localhost:50051", grpc.WithInsecure())
    if err != nil {
        log.Fatalf("did not connect: %v", err)
    }
    defer conn.Close()

    client := pb.NewExampleServiceClient(conn)

    // Unary RPC
    resp, err := client.GetMessage(context.Background(), &pb.MessageRequest{Name: "World"})
    if err != nil {
        log.Fatalf("could not get message: %v", err)
    }
    fmt.Println("Unary Response:", resp.Message)

    // Server-side streaming RPC
    streamResp, err := client.GetStreamMessages(context.Background(), &pb.StreamRequest{Count: 5})
    if err != nil {
        log.Fatalf("could not get stream messages: %v", err)
    }
    for {
        msg, err := streamResp.Recv()
        if err == io.EOF {
            break
        }
        if err != nil {
            log.Fatalf("error receiving stream message: %v", err)
        }
        fmt.Println("Stream Response:", msg.Message)
    }

    // Client-side streaming RPC
    clientStream, err := client.SendStreamMessages(context.Background())
    if err != nil {
        log.Fatalf("could not send stream messages: %v", err)
    }
    names := []string{"Alice", "Bob", "Charlie"}
    for _, name := range names {
        if err := clientStream.Send(&pb.MessageRequest{Name: name}); err != nil {
            log.Fatalf("error sending name: %v", err)
        }
    }
    resp, err = clientStream.CloseAndRecv()
    if err != nil {
        log.Fatalf("error receiving response: %v", err)
    }
    fmt.Println("Client Stream Response:", resp.Message)

    // Bidirectional streaming RPC
    chatStream, err := client.Chat(context.Background())
    if err != nil {
        log.Fatalf("could not start chat: %v", err)
    }

    go func() {
        for _, name := range names {
            if err := chatStream.Send(&pb.MessageRequest{Name: name}); err != nil {
                log.Fatalf("error sending name: %v", err)
            }
            time.Sleep(1 * time.Second)
        }
        chatStream.CloseSend()
    }()

    for {
        resp, err := chatStream.Recv()
        if err == io.EOF {
            break
        }
        if err != nil {
            log.Fatalf("error receiving chat message: %v", err)
        }
        fmt.Println("Chat Response:", resp.Message)
    }
}

