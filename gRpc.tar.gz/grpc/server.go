package main

import (
    "context"
    "fmt"
    "io"
    "log"
    "net"

    "google.golang.org/grpc"
    pb "example/examplep" // Update with your actual path
)

type server struct {
    pb.UnimplementedExampleServiceServer
}

// Unary RPC
func (s *server) GetMessage(ctx context.Context, req *pb.MessageRequest) (*pb.MessageResponse, error) {
    return &pb.MessageResponse{Message: "Hello " + req.Name}, nil
}

// Server-side streaming RPC
func (s *server) GetStreamMessages(req *pb.StreamRequest, stream pb.ExampleService_GetStreamMessagesServer) error {
    for i := 0; i < int(req.Count); i++ {
        msg := fmt.Sprintf("Message %d", i+1)
        if err := stream.Send(&pb.StreamResponse{Message: msg}); err != nil {
            return err
        }
    }
    return nil
}

// Client-side streaming RPC
func (s *server) SendStreamMessages(stream pb.ExampleService_SendStreamMessagesServer) error {
    var names []string
    for {
        req, err := stream.Recv()
        if err == io.EOF {
            break
        }
        if err != nil {
            return err
        }
        names = append(names, req.Name)
    }
    return stream.SendAndClose(&pb.MessageResponse{Message: "Received names: " + fmt.Sprint(names)})
}

// Bidirectional streaming RPC
func (s *server) Chat(stream pb.ExampleService_ChatServer) error {
    for {
        req, err := stream.Recv()
        if err == io.EOF {
            break
        }
        if err != nil {
            return err
        }
        response := &pb.MessageResponse{Message: "Hello " + req.Name}
        if err := stream.Send(response); err != nil {
            return err
        }
    }
    return nil
}

func main() {
    lis, err := net.Listen("tcp", ":50051")
    if err != nil {
        log.Fatalf("failed to listen: %v", err)
    }
    s := grpc.NewServer()
    pb.RegisterExampleServiceServer(s, &server{})
    log.Println("Server is running on port :50051")
    if err := s.Serve(lis); err != nil {
        log.Fatalf("failed to serve: %v", err)
    }
}

