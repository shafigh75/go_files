# commands to use :

### get the gRPC packages for golang:

```bash
go get google.golang.org/grpc
go get google.golang.org/protobuf/cmd/protoc-gen-go
go get google.golang.org/grpc/cmd/protoc-gen-go-grpc
```

### create the protobuffer file:

```bash
vim example.proto
```

### generate the boilerPlate codes from protoc command:

```bash
 protoc --go_out=. --go-grpc_out=. example.proto
 ```

### create server and client codes in golang:

```bash
vim server.go
vim client.go
```

##### *note that you need to create a proper go.mod as well. 