package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

// --- Configuration ---
const GEMINI_API_KEY = "AIzaSyD56-RNBQBGLFc_19H5A-80FtCltXJ0xug"
const MISTRAL_API_KEY = "1dATkWMIqq2HG2EU4dIxZar3zOJRsVEW"

const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + GEMINI_API_KEY
const MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"

// --- SSH Configuration ---
const SSH_HOST = "YOUR_SERVER_IP_OR_HOSTNAME"
const SSH_PORT = "22"
const SSH_USER = "YOUR_USERNAME"
const SSH_PASSWORD = "YOUR_PASSWORD"

// --- History Management Configuration ---
const MAX_HISTORY_TURNS = 8
const MAX_MESSAGE_LENGTH = 2000

// --- Structs ---
type ConnectRequest struct {
	Host       string `json:"host"`
	Port       string `json:"port"`
	User       string `json:"user"`
	AuthMethod string `json:"authMethod"`
	Password   string `json:"password,omitempty"`
	PrivateKey string `json:"privateKey,omitempty"`
	Passphrase string `json:"passphrase,omitempty"`
}
type ExecuteRequest struct {
	ConnectRequest
	Command string `json:"command"`
}
type PlanRequest struct {
	Prompt  string        `json:"prompt"`
	History []HistoryItem `json:"history"`
	Model   string        `json:"model"`
}
type HistoryItem struct {
	Role    string `json:"role"`
	Message string `json:"message"`
}
type PlanResponse struct {
	Command string `json:"command"`
	Thought string `json:"thought"`
	Error   string `json:"error,omitempty"`
}
type ExecuteResponse struct {
	Output string `json:"output"`
	Error  string `json:"error,omitempty"`
}
type GeminiRequestPart struct{ Text string `json:"text"` }
type GeminiRequestContent struct {
	Parts []GeminiRequestPart `json:"parts"`
	Role  string              `json:"role,omitempty"`
}
type GeminiRequestBody struct{ Contents []GeminiRequestContent `json:"contents"` }
type GeminiResponseCandidate struct{ Content struct{ Parts []struct{ Text string `json:"text"` } `json:"parts"` } `json:"content"` }
type GeminiResponseBody struct{ Candidates []GeminiResponseCandidate `json:"candidates"` }
type MistralMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}
type MistralRequestBody struct {
	Model          string           `json:"model"`
	Messages       []MistralMessage `json:"messages"`
	ResponseFormat map[string]string `json:"response_format"`
}
type MistralResponseBody struct {
	Choices []struct {
		Message struct {
			Content string `json:"content"`
		} `json:"message"`
	} `json:"choices"`
}

// --- UPDATED SYSTEM PROMPT ---
const SYSTEM_PROMPT = `You are a conversational AI assistant and an expert Linux system administrator.
First, determine the user's intent. Is it a request to perform an action (like list files) or is it a question/general chat (like 'what is the ls command for?').

- If the intent is to PERFORM AN ACTION:
  1. Formulate a concise, safe, and accurate shell command.
  2. Provide a brief "thought" explaining the command.
  3. Respond ONLY with a JSON object. The JSON object must be a compact, single-line string with no newlines or formatting. Example: {"thought": "reasoning", "command": "the_command"}.

- If the intent is a QUESTION or CHAT:
  1. Formulate a helpful answer or a friendly response.
  2. This answer is your "thought".
  3. Respond ONLY with a JSON object. The JSON object must be a compact, single-line string with no newlines or formatting. Example: {"thought": "answer", "command": ""}.`

// --- Helper Functions ---
func processHistory(history []HistoryItem) []HistoryItem {
	if len(history) > MAX_HISTORY_TURNS*2 {
		history = history[len(history)-MAX_HISTORY_TURNS*2:]
	}
	processedHistory := []HistoryItem{}
	for _, item := range history {
		if len(item.Message) > MAX_MESSAGE_LENGTH {
			item.Message = item.Message[:MAX_MESSAGE_LENGTH] + "\n\n[...output truncated...]"
		}
		processedHistory = append(processedHistory, item)
	}
	return processedHistory
}

func getSSHConfig(req ConnectRequest) (*ssh.ClientConfig, error) {
	var authMethods []ssh.AuthMethod
	if req.AuthMethod == "password" {
		authMethods = append(authMethods, ssh.Password(req.Password))
	} else if req.AuthMethod == "key" {
		var signer ssh.Signer
		var err error
		if req.Passphrase != "" {
			signer, err = ssh.ParsePrivateKeyWithPassphrase([]byte(req.PrivateKey), []byte(req.Passphrase))
		} else {
			signer, err = ssh.ParsePrivateKey([]byte(req.PrivateKey))
		}
		if err != nil {
			return nil, fmt.Errorf("unable to parse private key: %w", err)
		}
		authMethods = append(authMethods, ssh.PublicKeys(signer))
	} else {
		return nil, fmt.Errorf("invalid authentication method: %s", req.AuthMethod)
	}
	return &ssh.ClientConfig{
		User:            req.User,
		Auth:            authMethods,
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
		Timeout:         10 * time.Second,
	}, nil
}

// --- HTTP Handlers ---
func connectHandler(w http.ResponseWriter, r *http.Request) {
	var req ConnectRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil { http.Error(w, err.Error(), http.StatusBadRequest); return }
	sshConfig, err := getSSHConfig(req)
	if err != nil { http.Error(w, err.Error(), http.StatusBadRequest); return }
	client, err := ssh.Dial("tcp", req.Host+":"+req.Port, sshConfig)
	if err != nil {
		log.Printf("Failed to dial SSH for connection test: %v", err)
		http.Error(w, fmt.Sprintf("Connection failed: %v", err), http.StatusUnauthorized)
		return
	}
	client.Close()
	w.WriteHeader(http.StatusOK)
	fmt.Fprintln(w, "Connection successful!")
}

func planHandler(w http.ResponseWriter, r *http.Request) {
	var req PlanRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil { http.Error(w, err.Error(), http.StatusBadRequest); return }
	processedHistory := processHistory(req.History)
	var plan PlanResponse
	var err error
	switch req.Model {
	case "gemini":
		plan, err = getGeminiPlan(req.Prompt, processedHistory)
	case "mistral":
		plan, err = getMistralPlan(req.Prompt, processedHistory)
	default:
		err = fmt.Errorf("unknown model requested: %s", req.Model)
	}
	if err != nil { log.Printf("ERROR: %v", err); plan.Error = err.Error() }
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(plan)
}

func executeHandler(w http.ResponseWriter, r *http.Request) {
	var req ExecuteRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil { http.Error(w, err.Error(), http.StatusBadRequest); return }
	sshConfig, err := getSSHConfig(req.ConnectRequest)
	if err != nil { http.Error(w, err.Error(), http.StatusBadRequest); return }
	client, err := ssh.Dial("tcp", req.Host+":"+req.Port, sshConfig)
	if err != nil { log.Printf("Failed to dial SSH for execution: %v", err); http.Error(w, "Failed to connect to the server via SSH.", http.StatusInternalServerError); return }
	defer client.Close()
	session, err := client.NewSession()
	if err != nil { log.Printf("Failed to create SSH session: %v", err); http.Error(w, "Failed to create SSH session.", http.StatusInternalServerError); return }
	defer session.Close()
	output, err := session.CombinedOutput(req.Command)
	response := ExecuteResponse{Output: string(output)}
	if err != nil { log.Printf("SSH command execution failed: %v", err); response.Error = err.Error() }
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func getGeminiPlan(prompt string, history []HistoryItem) (PlanResponse, error) {
	contents := []GeminiRequestContent{
		{Parts: []GeminiRequestPart{{Text: SYSTEM_PROMPT}}, Role: "user"},
		{Parts: []GeminiRequestPart{{Text: "Understood. I will determine the user's intent and respond in the required JSON format."}}, Role: "model"},
	}
	for _, item := range history {
		contents = append(contents, GeminiRequestContent{Parts: []GeminiRequestPart{{Text: item.Message}}, Role: item.Role})
	}
	contents = append(contents, GeminiRequestContent{Parts: []GeminiRequestPart{{Text: prompt}}, Role: "user"})
	reqBodyBytes, _ := json.Marshal(GeminiRequestBody{Contents: contents})
	resp, err := http.Post(GEMINI_API_URL, "application/json", bytes.NewBuffer(reqBodyBytes))
	if err != nil { return PlanResponse{}, fmt.Errorf("error calling Gemini API: %w", err) }
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var geminiRespBody GeminiResponseBody
	if err := json.Unmarshal(body, &geminiRespBody); err != nil { return PlanResponse{}, fmt.Errorf("failed to decode Gemini JSON response. Status: %s, Body: %s", resp.Status, string(body)) }
	var plan PlanResponse
	if len(geminiRespBody.Candidates) > 0 && len(geminiRespBody.Candidates[0].Content.Parts) > 0 {
		rawResponse := geminiRespBody.Candidates[0].Content.Parts[0].Text
		startIndex := strings.Index(rawResponse, "{")
		endIndex := strings.LastIndex(rawResponse, "}")
		if startIndex != -1 && endIndex != -1 && endIndex > startIndex {
			jsonStr := rawResponse[startIndex : endIndex+1]
			if err := json.Unmarshal([]byte(jsonStr), &plan); err != nil { return PlanResponse{}, fmt.Errorf("AI returned invalid JSON plan. Raw: %s", rawResponse) }
		} else {
			// --- FIX APPLIED HERE ---
			// If no JSON is found, treat the entire response as a "thought" and don't return an error.
			plan.Thought = rawResponse
			plan.Command = ""
		}
	} else { return PlanResponse{}, fmt.Errorf("AI returned no response or unexpected structure. Full body: %s", string(body)) }
	return plan, nil
}

func getMistralPlan(prompt string, history []HistoryItem) (PlanResponse, error) {
	messages := []MistralMessage{{Role: "system", Content: SYSTEM_PROMPT}}
	for _, item := range history {
		role := "user"
		if item.Role == "model" { role = "assistant" }
		messages = append(messages, MistralMessage{Role: role, Content: item.Message})
	}
	messages = append(messages, MistralMessage{Role: "user", Content: prompt})
	reqBody := MistralRequestBody{
		Model:          "mistral-large-latest",
		Messages:       messages,
		ResponseFormat: map[string]string{"type": "json_object"},
	}
	reqBodyBytes, _ := json.Marshal(reqBody)
	req, _ := http.NewRequest("POST", MISTRAL_API_URL, bytes.NewBuffer(reqBodyBytes))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+MISTRAL_API_KEY)
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil { return PlanResponse{}, fmt.Errorf("error calling Mistral API: %w", err) }
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var mistralRespBody MistralResponseBody
	if err := json.Unmarshal(body, &mistralRespBody); err != nil { return PlanResponse{}, fmt.Errorf("failed to decode Mistral JSON response. Status: %s, Body: %s", resp.Status, string(body)) }
	var plan PlanResponse
	if len(mistralRespBody.Choices) > 0 {
		rawResponse := mistralRespBody.Choices[0].Message.Content
		startIndex := strings.Index(rawResponse, "{")
		endIndex := strings.LastIndex(rawResponse, "}")
		if startIndex != -1 && endIndex != -1 && endIndex > startIndex {
			jsonStr := rawResponse[startIndex : endIndex+1]
			if err := json.Unmarshal([]byte(jsonStr), &plan); err != nil { return PlanResponse{}, fmt.Errorf("Mistral returned invalid JSON plan. Raw: %s", rawResponse) }
		} else {
			// --- FIX APPLIED HERE ---
			// If no JSON is found, treat the entire response as a "thought" and don't return an error.
			plan.Thought = rawResponse
			plan.Command = ""
		}
	} else { return PlanResponse{}, fmt.Errorf("Mistral returned no response. Full body: %s", string(body)) }
	return plan, nil
}

func main() {
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) { http.ServeFile(w, r, "index.html") })
	http.HandleFunc("/connect", connectHandler)
	http.HandleFunc("/plan", planHandler)
	http.HandleFunc("/execute", executeHandler)
	fmt.Println("Server starting on http://localhost:8080")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatalf("Could not start server: %s\n", err)
	}
}

