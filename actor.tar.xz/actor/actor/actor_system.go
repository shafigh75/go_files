package actor

import "sync"

// ActorSystem manages all actors.
type ActorSystem struct {
	actors    map[string]*actorWrapper
	mutex     sync.Mutex
	waitGroup sync.WaitGroup
}

// NewActorSystem creates a new actor system.
func NewActorSystem() *ActorSystem {
	return &ActorSystem{
		actors: make(map[string]*actorWrapper),
	}
}

// SpawnActor creates a new actor.
func (as *ActorSystem) SpawnActor(name string, actor Actor) {
	as.mutex.Lock()
	defer as.mutex.Unlock()

	if _, exists := as.actors[name]; exists {
		panic("Actor with name already exists")
	}

	aw := &actorWrapper{
		actor:     actor,
		mailbox:   make(chan Message, 100),
		shutdown:  make(chan struct{}),
		waitGroup: &as.waitGroup,
	}

	as.actors[name] = aw
	aw.start()
}

// SendMessage sends a message to an actor.
func (as *ActorSystem) SendMessage(name string, msg Message) {
	as.mutex.Lock()
	aw, exists := as.actors[name]
	as.mutex.Unlock()

	if exists {
		aw.mailbox <- msg
	}
}

// StopActor stops an actor.
func (as *ActorSystem) StopActor(name string) {
	as.mutex.Lock()
	aw, exists := as.actors[name]
	if exists {
		aw.stop()
		delete(as.actors, name)
	}
	as.mutex.Unlock()
}

// Shutdown stops all actors gracefully.
func (as *ActorSystem) Shutdown() {
	as.mutex.Lock()
	for name, aw := range as.actors {
		aw.stop()
		delete(as.actors, name)
	}
	as.mutex.Unlock()
	as.waitGroup.Wait()
}
