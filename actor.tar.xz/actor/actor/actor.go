package actor

import (
	"sync"
)

// Message is a generic interface for all messages.
type Message interface{}

// Actor interface defines the behavior of an actor.
type Actor interface {
	Receive(msg Message)
}

// actorWrapper wraps an Actor to run in a goroutine.
type actorWrapper struct {
	actor     Actor
	mailbox   chan Message
	shutdown  chan struct{}
	waitGroup *sync.WaitGroup
}

// Start the actor loop
func (aw *actorWrapper) start() {
	aw.waitGroup.Add(1)
	go func() {
		defer aw.waitGroup.Done()
		for {
			select {
			case msg := <-aw.mailbox:
				aw.actor.Receive(msg)
			case <-aw.shutdown:
				return
			}
		}
	}()
}

// Stop the actor
func (aw *actorWrapper) stop() {
	close(aw.shutdown)
	close(aw.mailbox)
}
