package actors

import (
	"example/actor"
	"example/messages"
	"fmt"
)

// PaymentActor handles payments.
type PaymentActor struct {
	system *actor.ActorSystem
}

// NewPaymentActor creates a new PaymentActor.
func NewPaymentActor(system *actor.ActorSystem) *PaymentActor {
	return &PaymentActor{system: system}
}

// Receive handles payment messages.
func (p *PaymentActor) Receive(msg actor.Message) {
	switch m := msg.(type) {
	case messages.PaymentMessage:
		fmt.Printf("Processing payment of $%.2f for order %s\n", m.Amount, m.OrderID)

		// Send inventory update request
		p.system.SendMessage("inventory", messages.InventoryMessage{
			OrderID: m.OrderID, ItemID: "item123", Quantity: 1,
		})

		// Send order confirmation notification
		p.system.SendMessage("notification", messages.NotificationMessage{
			UserID: m.UserID, Message: "Your order has been confirmed!",
		})
	}
}
