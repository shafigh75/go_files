package actors

import (
	"example/actor"
	"example/messages"
	"fmt"
)

// OrderActor processes new orders.
type OrderActor struct {
	system *actor.ActorSystem
}

// NewOrderActor creates a new OrderActor.
func NewOrderActor(system *actor.ActorSystem) *OrderActor {
	return &OrderActor{system: system}
}

// Receive processes order messages.
func (o *OrderActor) Receive(msg actor.Message) {
	switch m := msg.(type) {
	case messages.OrderMessage:
		fmt.Printf("Processing order %s for user %s\n", m.OrderID, m.UserID)

		// Send payment request
		o.system.SendMessage("payment", messages.PaymentMessage{
			OrderID: m.OrderID, UserID: m.UserID, Amount: m.Amount,
		})
	}
}
