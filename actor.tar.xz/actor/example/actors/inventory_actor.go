package actors

import (
	"example/actor"
	"example/messages"
	"fmt"
)

// InventoryActor updates stock.
type InventoryActor struct{}

// NewInventoryActor creates a new InventoryActor.
func NewInventoryActor() *InventoryActor {
	return &InventoryActor{}
}

// Receive handles inventory messages.
func (i *InventoryActor) Receive(msg actor.Message) {
	switch m := msg.(type) {
	case messages.InventoryMessage:
		fmt.Printf("Updating inventory for order %s: item %s, quantity %d\n",
			m.OrderID, m.ItemID, m.Quantity)
	}
}
