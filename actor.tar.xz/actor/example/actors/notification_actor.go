package actors

import (
	"example/actor"
	"example/messages"
	"fmt"
)

// NotificationActor sends notifications.
type NotificationActor struct{}

// NewNotificationActor creates a new NotificationActor.
func NewNotificationActor() *NotificationActor {
	return &NotificationActor{}
}

// Receive handles notification messages.
func (n *NotificationActor) Receive(msg actor.Message) {
	switch m := msg.(type) {
	case messages.NotificationMessage:
		fmt.Printf("Sending notification to user %s: %s\n", m.UserID, m.Message)
	}
}
