package messages

// OrderMessage represents a new order request.
type OrderMessage struct {
	OrderID string
	UserID  string
	Amount  float64
}

// PaymentMessage represents a payment request.
type PaymentMessage struct {
	OrderID string
	UserID  string
	Amount  float64
}

// InventoryMessage represents an inventory update request.
type InventoryMessage struct {
	OrderID  string
	ItemID   string
	Quantity int
}

// NotificationMessage represents a user notification.
type NotificationMessage struct {
	UserID  string
	Message string
}
