package main

import (
	"example/actor"
	"example/actors"
	"example/messages"
	"time"
)

func main() {
	system := actor.NewActorSystem()

	// Spawn actors
	system.SpawnActor("order", actors.NewOrderActor(system))
	system.SpawnActor("payment", actors.NewPaymentActor(system))
	system.SpawnActor("inventory", actors.NewInventoryActor())
	system.SpawnActor("notification", actors.NewNotificationActor())

	// Simulate order processing
	system.SendMessage("order", messages.OrderMessage{
		OrderID: "order123", UserID: "user456", Amount: 100.00,
	})

	// Allow time for message processing
	time.Sleep(1 * time.Second)

	// Shutdown system
	system.Shutdown()
}
