package main

import (
	"fmt"
	"mohammad/actor"
	"time"
)

func main() {
	system := actor.NewActorSystem()

	// Spawn a CounterActor
	system.SpawnActor("counter", &CounterActor{})

	// Send messages to the CounterActor
	for i := 1; i <= 10; i++ {
		system.SendMessage("counter", CounterMessage{Increment: i})
		time.Sleep(100 * time.Millisecond)
	}

	// Shutdown the system
	system.Shutdown()
	fmt.Println("Actor system shut down.")
}
