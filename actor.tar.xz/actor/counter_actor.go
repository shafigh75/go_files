package main

import (
	"fmt"
	"mohammad/actor"
)

// CounterMessage defines messages for CounterActor.
type CounterMessage struct {
	Increment int
}

// CounterActor maintains a counter.
type CounterActor struct {
	count int
}

// Receive handles incoming messages.
func (c *CounterActor) Receive(msg actor.Message) {
	switch m := msg.(type) {
	case CounterMessage:
		c.count += m.Increment
		fmt.Println("Counter:", c.count)
	}
}
