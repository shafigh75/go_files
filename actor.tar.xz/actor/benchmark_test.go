package main

import (
	"mohammad/actor"
	"testing"
)

func BenchmarkActorSystem(b *testing.B) {
	system := actor.NewActorSystem()
	system.SpawnActor("counter", &CounterActor{})

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		system.SendMessage("counter", CounterMessage{Increment: 1})
	}

	system.Shutdown()
}
