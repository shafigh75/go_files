// main.go
package main

import (
    "os"
    "strings"

    "github.com/fatih/color"
    "github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
    Use:   "prettycli",
    Short: "PrettyCLI is a simple and pretty CLI tool built with Go",
    Long:  `PrettyCLI is a demonstration CLI tool that shows how to use Cobra for building a simple, yet pretty, CLI application in Go.`,
    Run: func(cmd *cobra.Command, args []string) {
        color.Cyan("Welcome to PrettyCLI! Use --help to see available commands.")
    },
}

var echoCmd = &cobra.Command{
    Use:   "echo [message]",
    Short: "Echo prints the input message",
    Long:  `Echo prints the input message to the console.`,
    Args:  cobra.MinimumNArgs(1),
    Run: func(cmd *cobra.Command, args []string) {
      d := color.New(color.FgRed, color.Bold)
      d.Printf("%s",strings.Join(args, " "))
    },
}

func main() {
    rootCmd.AddCommand(echoCmd)
    if err := rootCmd.Execute(); err != nil {
        color.Red(err.Error())
        os.Exit(1)
    }
}

