// math_test.go
package myMath

import (
    "testing"
)

func TestAdd(t *testing.T) {
    result := Add(2, 3)
    expected := 4

    if result != expected {
        t.Errorf("Add(2, 3) = %d; want %d", result, expected)
    }
}

