// math.go
package myMath

// Add adds two integers and returns the result.
func Add(a, b int) int {
    return a + b
}


func differ(a, b int) int {
    return a - b
}
