// variables,  math operations, conditionals and loops 

package main

import (
    "fmt"
)

func main() {
    // Variable declaration and initialization
    var a int = 5
    var b int = 3

    // Short variable declaration
    c := a + b
    d := a * b

    // Math operations
    fmt.Println("Addition: ", c)
    fmt.Println("Multiplication: ", d)

    // Conditionals
    if c > d {
        fmt.Println("c is greater than d")
    } else if c < d {
        fmt.Println("c is less than d")
    } else {
        fmt.Println("c is equal to d")
    }

    // Loops - For loop
    fmt.Println("For loop:")
    for i := 0; i < 5; i++ {
        fmt.Println("i:", i)
    }

    // Loops - While loop using for
    fmt.Println("While loop:")
    count := 0
    for count < 5 {
        fmt.Println("count:", count)
        count++
    }

    // Loops - Infinite loop with break
    fmt.Println("Infinite loop with break:")
    n := 0
    for {
        if n >= 5 {
            break
        }
        fmt.Println("n:", n)
        n++
    }
}



//////////////////////////////////////////////////////////


// golang types


package main

import (
    "fmt"
    "math"
)

func main() {
    // Integer types
    var a int = 42
    var b int8 = -128
    var c int16 = 32767
    var d int32 = 2147483647
    var e int64 = 9223372036854775807

    // Unsigned integer types
    var ua uint = 42
    var ub uint8 = 255
    var uc uint16 = 65535
    var ud uint32 = 4294967295
    var ue uint64 = 18446744073709551615

    // Floating-point types
    var fa float32 = 3.14
    var fb float64 = 2.718281828459045

    // Complex types
    var ca complex64 = 1 + 2i
    var cb complex128 = 2 + 3i

    // Boolean type
    var flag bool = true

    // String type
    var name string = "Golang"

    // Print integer types
    fmt.Println("Integer Types:")
    fmt.Println("a:", a)
    fmt.Println("b:", b)
    fmt.Println("c:", c)
    fmt.Println("d:", d)
    fmt.Println("e:", e)

    // Print unsigned integer types
    fmt.Println("Unsigned Integer Types:")
    fmt.Println("ua:", ua)
    fmt.Println("ub:", ub)
    fmt.Println("uc:", uc)
    fmt.Println("ud:", ud)
    fmt.Println("ue:", ue)

    // Print floating-point types
    fmt.Println("Floating-point Types:")
    fmt.Println("fa:", fa)
    fmt.Println("fb:", fb)

    // Print complex types
    fmt.Println("Complex Types:")
    fmt.Println("ca:", ca)
    fmt.Println("cb:", cb)

    // Print boolean type
    fmt.Println("Boolean Type:")
    fmt.Println("flag:", flag)

    // Print string type
    fmt.Println("String Type:")
    fmt.Println("name:", name)

    // Additional examples of type conversions
    fmt.Println("Type Conversions:")
    x := int(fa) // Convert float32 to int
    y := float64(a) // Convert int to float64
    fmt.Println("x (float32 to int):", x)
    fmt.Println("y (int to float64):", y)

    // Using the math package
    fmt.Println("Math Package Functions:")
    fmt.Println("Sqrt of 16:", math.Sqrt(16))
    fmt.Println("Pi:", math.Pi)
}
//////////////////////////////////////////////////////////


//structs and interfaces and functions 

package main

import (
    "fmt"
)

// Define a struct
type Person struct {
    firstName string
    lastName  string
    age       int
}

// Method associated with the Person struct
func (p Person) fullName() string {
    return p.firstName + " " + p.lastName
}

// Define an interface
type Describer interface {
    describe() string
}

// Implement the describe method for Person struct
func (p Person) describe() string {
    return fmt.Sprintf("Name: %s, Age: %d", p.fullName(), p.age)
}

// Function that accepts an interface
func printDescription(d Describer) {
    fmt.Println(d.describe())
}

func main() {
    // Create an instance of Person
    person := Person{
        firstName: "John",
        lastName:  "Doe",
        age:       30,
    }

    // Call method on the struct
    fmt.Println("Full Name:", person.fullName())

    // Use the interface
    printDescription(person)
}




//////////////////////////////////////////////////////////



//struct embedding and composition using interfaces

package main

import (
    "fmt"
)

// Define a struct
type Person struct {
    firstName string
    lastName  string
    age       int
}

// Method associated with the Person struct
func (p Person) fullName() string {
    return p.firstName + " " + p.lastName
}

// Another struct embedding Person
type Employee struct {
    Person
    employeeID string
    position   string
}

// Define an interface
type Describer interface {
    describe() string
}

// Implement the describe method for Person struct
func (p Person) describe() string {
    return fmt.Sprintf("Name: %s, Age: %d", p.fullName(), p.age)
}

// Implement the describe method for Employee struct
func (e Employee) describe() string {
    return fmt.Sprintf("Name: %s, Age: %d, Employee ID: %s, Position: %s", e.fullName(), e.age, e.employeeID, e.position)
}

// Function that accepts an interface
func printDescription(d Describer) {
    fmt.Println(d.describe())
}

func main() {
    // Create an instance of Person
    person := Person{
        firstName: "John",
        lastName:  "Doe",
        age:       30,
    }

    // Create an instance of Employee
    employee := Employee{
        Person: Person{
            firstName: "Alice",
            lastName:  "Smith",
            age:       28,
        },
        employeeID: "E12345",
        position:   "Developer",
    }

    // Use the interface
    fmt.Println("Person Description:")
    printDescription(person)

    fmt.Println("Employee Description:")
    printDescription(employee)
}






//////////////////////////////////////////////////////////


// goroutines and channels 

package main

import (
    "fmt"
    "time"
)

// Function that will run as a goroutine
func printNumbers(id int, ch chan<- int) {
    for i := 1; i <= 5; i++ {
        ch <- i // Send number to channel
        time.Sleep(500 * time.Millisecond) // Simulate work by sleeping
    }
    close(ch) // Close the channel when done
}

func main() {
    // Create a channel to communicate between goroutines
    ch := make(chan int)

    // Start a goroutine
    go printNumbers(1, ch)

    // Receive values from the channel
    for num := range ch {
        fmt.Println(num)
    }

    fmt.Println("All numbers printed!")
}



//////////////////////////////////////////////////////////


// webserver

package main

import (
    "fmt"
    "net/http"
)

// handler for the root route
func homeHandler(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "Welcome to the Home Page!")
}

// handler for the about route
func aboutHandler(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "This is the About Page.")
}

// handler for the contact route
func contactHandler(w http.ResponseWriter, r *http.Request) {
    fmt.Fprintf(w, "This is the Contact Page.")
}

func main() {
    // Register route handlers
    http.HandleFunc("/", homeHandler)
    http.HandleFunc("/about", aboutHandler)
    http.HandleFunc("/contact", contactHandler)

    // Start the web server on port 8080
    fmt.Println("Starting server at port 8080")
    if err := http.ListenAndServe(":8080", nil); err != nil {
        fmt.Printf("Error starting server: %s\n", err)
    }
}



//////////////////////////////////////////////////////////

// JSON encode and decoding

package main

import (
    "encoding/json"
    "fmt"
)

type Person struct {
    Name  string
    Age   int
    Email string
}

func main() {
    person := Person{"Alice", 30, "alice@example.com"}
    
    // Encode to JSON
    jsonData, _ := json.Marshal(person)
    fmt.Println(string(jsonData))
    
    // Decode from JSON
    var decodedPerson Person
    json.Unmarshal(jsonData, &decodedPerson)
    fmt.Println(decodedPerson)
}



//////////////////////////////////////////////////////////

// reading and writing to a file


package main

import (
    "bufio"
    "fmt"
    "os"
)

func main() {
    file, err := os.Open("example.txt")
    if err != nil {
        fmt.Println(err)
        return
    }
    defer file.Close()

    scanner := bufio.NewScanner(file)
    for scanner.Scan() {
        fmt.Println(scanner.Text())
    }

    if err := scanner.Err(); err != nil {
        fmt.Println(err)
    }
}



//////////////////////////////////////////////////////////////


package main

import (
    "bufio"
    "fmt"
    "os"
)

func main() {
    // Create a file for writing
    file, err := os.Create("output.txt")
    if err != nil {
        fmt.Println(err)
        return
    }
    defer file.Close()

    // Create a writer to write to the file
    writer := bufio.NewWriter(file)
    _, err = writer.WriteString("Hello, World!\nThis is a line of text.\n")
    if err != nil {
        fmt.Println(err)
        return
    }

    // Flush the buffered writer to ensure all data is written to the file
    writer.Flush()
}



