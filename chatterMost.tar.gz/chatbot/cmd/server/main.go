package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/cors"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/joho/godotenv"

	"github.com/acme/realtime-chat/internal/config"
	"github.com/acme/realtime-chat/internal/db"
	"github.com/acme/realtime-chat/internal/handlers"
	"github.com/acme/realtime-chat/internal/ws"
)

func main() {
	_ = godotenv.Load()
	cfg := config.Load()

	ctx := context.Background()
	pool, err := pgxpool.New(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("db connect error: %v", err)
	}
	defer pool.Close()

	if err := db.RunMigrationsFromDir(ctx, pool, "db/migrations"); err != nil {
		log.Fatalf("migrations error: %v", err)
	}

	messageHub := ws.NewHub(pool)
	go messageHub.Run()

	r := chi.NewRouter()
	r.Use(cors.Handler(cors.Options{
		AllowedOrigins:   []string{cfg.Origin},
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type"},
		ExposedHeaders:   []string{"Link"},
		AllowCredentials: true,
		MaxAge:           300,
	}))

	h := handlers.New(pool, messageHub, cfg)
	r.Get("/", h.Index)
	r.Get("/healthz", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })

	r.Route("/api", func(r chi.Router) {
		r.Post("/register", h.Register)
		r.Post("/login", h.Login)
		r.Post("/logout", h.Logout)
		r.Get("/me", h.Me)
		r.Get("/profile", h.GetProfile)
		r.Put("/profile", h.UpdateProfile)
		r.Get("/users", h.SearchUsers)
		r.Get("/conversations", h.ListConversations)
		r.Post("/conversations", h.CreateConversation)
		r.Delete("/conversations/{id}", h.DeleteConversation)
		r.Put("/conversations/{id}/read", h.MarkConversationRead)
		r.Get("/messages", h.ListMessages)
		r.Delete("/messages/{id}", h.DeleteMessage)
		r.Post("/upload", h.UploadMedia)
		r.Get("/debug/unread", h.DebugUnreadCount)

		// Channel endpoints
		r.Post("/channels", h.CreateChannel)
		r.Get("/channels", h.ListChannels)
		r.Post("/channels/{id}/subscribe", h.SubscribeChannel)
		r.Post("/channels/{id}/unsubscribe", h.UnsubscribeChannel)
		r.Get("/channels/posts", h.ListChannelPosts)
		r.Post("/channels/{id}/post", h.PostToChannel)
		r.Delete("/channels/posts/{id}", h.DeleteChannelPost)
		r.Delete("/channels/{id}", h.DeleteChannel)
	})

	r.HandleFunc("/ws", h.Websocket)

	fs := http.FileServer(http.Dir(cfg.UploadDir))
	r.Handle("/uploads/*", http.StripPrefix("/uploads/", fs))

	// Serve static files from web/src
	webSrcFS := http.FileServer(http.Dir("web/src"))
	r.Handle("/src/*", http.StripPrefix("/src/", webSrcFS))

	cfg.Port = "8080"
	addr := fmt.Sprintf("%s:%s", cfg.Host, cfg.Port)
	srv := &http.Server{
		Addr:              addr,
		Handler:           r,
		ReadHeaderTimeout: 10 * time.Second,
	}
	log.Printf("listening on %s", addr)
	if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Println("server error:", err)
		os.Exit(1)
	}
}
