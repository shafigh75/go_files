package models

import (
	"time"

	"github.com/google/uuid"
)

type Channel struct {
	ID          uuid.UUID
	Name        string
	Description *string
	CreatorID   uuid.UUID
	CreatedAt   time.Time
}

type ChannelPost struct {
	ID        uuid.UUID
	ChannelID uuid.UUID
	SenderID  uuid.UUID
	Content   *string
	MediaURL  *string
	CreatedAt time.Time
}

type User struct {
	ID        uuid.UUID
	Username  string
	Email     string
	CreatedAt time.Time
}

type Conversation struct {
	ID        uuid.UUID
	IsGroup   bool
	Name      *string
	CreatedAt time.Time
}

type Message struct {
	ID             uuid.UUID
	ConversationID uuid.UUID
	SenderID       uuid.UUID
	Content        *string
	MediaURL       *string
	CreatedAt      time.Time
}
