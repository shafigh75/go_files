package ws

import (
	"context"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
	nws "nhooyr.io/websocket"
	"nhooyr.io/websocket/wsjson"
)

type Hub struct {
	pool       *pgxpool.Pool
	clients    map[uuid.UUID]map[*nws.Conn]struct{}
	register   chan registration
	unregister chan registration
	mtx        sync.RWMutex
}

type registration struct {
	userID uuid.UUID
	conn   *nws.Conn
}

type IncomingMessage struct {
	Type           string `json:"type"`
	ConversationID string `json:"conversation_id"`
	Content        string `json:"content"`
	MediaURL       string `json:"media_url"`
}

type MessageEvent struct {
	Type           string    `json:"type"`
	ID             uuid.UUID `json:"id"`
	ConversationID uuid.UUID `json:"conversation_id"`
	SenderID       uuid.UUID `json:"sender_id"`
	Content        *string   `json:"content,omitempty"`
	MediaURL       *string   `json:"media_url,omitempty"`
	CreatedAt      time.Time `json:"created_at"`
}

func NewHub(pool *pgxpool.Pool) *Hub {
	return &Hub{
		pool:       pool,
		clients:    make(map[uuid.UUID]map[*nws.Conn]struct{}),
		register:   make(chan registration),
		unregister: make(chan registration),
	}
}

func (h *Hub) Run() {
	for {
		select {
		case reg := <-h.register:
			h.mtx.Lock()
			if h.clients[reg.userID] == nil {
				h.clients[reg.userID] = make(map[*nws.Conn]struct{})
			}
			h.clients[reg.userID][reg.conn] = struct{}{}
			h.mtx.Unlock()
		case reg := <-h.unregister:
			h.mtx.Lock()
			if conns, ok := h.clients[reg.userID]; ok {
				delete(conns, reg.conn)
				if len(conns) == 0 {
					delete(h.clients, reg.userID)
				}
			}
			h.mtx.Unlock()
		}
	}
}

func (h *Hub) ServeWS(w http.ResponseWriter, r *http.Request, userID uuid.UUID) {
	conn, err := nws.Accept(w, r, &nws.AcceptOptions{InsecureSkipVerify: true})
	if err != nil {
		return
	}
	reg := registration{userID: userID, conn: conn}
	h.register <- reg
	defer func() { h.unregister <- reg; conn.Close(nws.StatusNormalClosure, "bye") }()

	ctx := r.Context()
	for {
		var incoming IncomingMessage
		if err := wsjson.Read(ctx, conn, &incoming); err != nil {
			// Suppress noisy close logs
			if s := nws.CloseStatus(err); s == nws.StatusNormalClosure || s == nws.StatusGoingAway || s == nws.StatusNoStatusRcvd {
				return
			}
			log.Println("ws read:", err)
			return
		}
		if incoming.Type == "message.send" {
			h.handleSendMessage(ctx, userID, incoming)
		}
	}
}

func (h *Hub) handleSendMessage(ctx context.Context, userID uuid.UUID, in IncomingMessage) {
	convID, err := uuid.Parse(in.ConversationID)
	if err != nil {
		return
	}
	// verify membership
	var exists bool
	err = h.pool.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM conversation_participants WHERE conversation_id=$1 AND user_id=$2)`, convID, userID).Scan(&exists)
	if err != nil || !exists {
		return
	}
	// persist message
	var id uuid.UUID
	var created time.Time
	err = h.pool.QueryRow(ctx, `INSERT INTO messages(conversation_id, sender_id, content, media_url) VALUES($1,$2,$3,$4) RETURNING id, created_at`, convID, userID, nullIfEmpty(in.Content), nullIfEmpty(in.MediaURL)).Scan(&id, &created)
	if err != nil {
		log.Println("insert message:", err)
		return
	}
	var contentPtr, mediaPtr *string
	if in.Content != "" {
		contentPtr = &in.Content
	}
	if in.MediaURL != "" {
		mediaPtr = &in.MediaURL
	}
	ev := MessageEvent{Type: "message.new", ID: id, ConversationID: convID, SenderID: userID, Content: contentPtr, MediaURL: mediaPtr, CreatedAt: created}
	// get participants and emit message + unread updates
	rows, err := h.pool.Query(ctx, `SELECT user_id FROM conversation_participants WHERE conversation_id=$1`, convID)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var pid uuid.UUID
			if err := rows.Scan(&pid); err == nil {
				// Send message to all participants
				h.broadcast(pid, ev)
				// Send unread count update to all participants except sender
				if pid != userID {
					h.emitUnreadUpdate(pid, convID)
				}
			}
		}
	}
}

func (h *Hub) emitUnreadUpdate(userID uuid.UUID, convID uuid.UUID) {
	ctx := context.Background()
	var unreadCount int
	err := h.pool.QueryRow(ctx, `
		SELECT COUNT(*) FROM messages m 
		WHERE m.conversation_id = $1 
		AND m.deleted_at IS NULL 
		AND m.sender_id <> $2
		AND (m.created_at > COALESCE((
			SELECT last_read_at FROM user_conversation_reads 
			WHERE user_id = $2 AND conversation_id = $1
		), '1970-01-01'::timestamptz))
	`, convID, userID).Scan(&unreadCount)
	if err != nil {
		return
	}
	payload := map[string]any{
		"type":            "unread.update",
		"conversation_id": convID,
		"unread_count":    unreadCount,
	}
	h.Emit(userID, payload)
}

func (h *Hub) broadcast(userID uuid.UUID, ev MessageEvent) {
	h.mtx.RLock()
	conns := h.clients[userID]
	h.mtx.RUnlock()
	for c := range conns {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = wsjson.Write(ctx, c, ev)
		cancel()
	}
}

func (h *Hub) Emit(userID uuid.UUID, payload any) {
	h.mtx.RLock()
	conns := h.clients[userID]
	h.mtx.RUnlock()
	for c := range conns {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = wsjson.Write(ctx, c, payload)
		cancel()
	}
}

func nullIfEmpty(s string) *string {
	if s == "" {
		return nil
	}
	return &s
}
