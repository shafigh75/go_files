package ws

// Package ws provides a simple websocket hub for realtime messaging.
