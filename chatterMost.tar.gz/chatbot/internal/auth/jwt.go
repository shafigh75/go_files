package auth

import (
	"net/http"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
)

type Claims struct {
	UserID string `json:"uid"`
	jwt.RegisteredClaims
}

func CreateJWT(userID uuid.UUID, secret string, ttl time.Duration) (string, error) {
	claims := Claims{
		UserID: userID.String(),
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(ttl)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}
	t := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return t.SignedString([]byte(secret))
}

func ParseJWT(tokenStr, secret string) (*Claims, error) {
	claims := &Claims{}
	_, err := jwt.ParseWithClaims(tokenStr, claims, func(t *jwt.Token) (interface{}, error) {
		return []byte(secret), nil
	})
	if err != nil {
		return nil, err
	}
	return claims, nil
}

func UserIDFromRequest(r *http.Request, secret string) (uuid.UUID, bool) {
	c, err := r.Cookie("auth_token")
	if err != nil || c.Value == "" {
		return uuid.UUID{}, false
	}
	claims, err := ParseJWT(c.Value, secret)
	if err != nil {
		return uuid.UUID{}, false
	}
	uid, err := uuid.Parse(claims.UserID)
	if err != nil {
		return uuid.UUID{}, false
	}
	return uid, true
}
