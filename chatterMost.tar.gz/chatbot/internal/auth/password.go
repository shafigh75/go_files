package auth

import "github.com/alexedwards/argon2id"

func HashPassword(plain string) (string, error) {
	return argon2id.CreateHash(plain, argon2id.DefaultParams)
}

func VerifyPassword(hash, plain string) (bool, error) {
	return argon2id.ComparePasswordAndHash(plain, hash)
}
