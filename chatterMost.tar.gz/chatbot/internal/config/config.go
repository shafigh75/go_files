package config

import (
	"log"
	"os"
)

type Config struct {
	Port        string
	Host        string
	DatabaseURL string
	JWTSecret   string
	UploadDir   string
	Origin      string
}

func Load() Config {
	cfg := Config{
		Port:        getEnv("PORT", "8080"),
		Host:        getEnv("HOST", "0.0.0.0"),
		DatabaseURL: getEnv("DATABASE_URL", "postgres://postgres:postgres@localhost:5432/chatapp?sslmode=disable"),
		JWTSecret:   getEnv("JWT_SECRET", "change-me"),
		UploadDir:   getEnv("UPLOAD_DIR", "./uploads"),
		Origin:      getEnv("ORIGIN", "http://localhost:8080"),
	}
	if err := os.MkdirAll(cfg.UploadDir, 0755); err != nil {
		log.Fatalf("failed to create upload dir: %v", err)
	}
	return cfg
}

func getEnv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}
