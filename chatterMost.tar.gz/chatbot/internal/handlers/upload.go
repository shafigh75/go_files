package handlers

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/google/uuid"

	"github.com/acme/realtime-chat/internal/auth"
)

func (h *Handlers) UploadMedia(w http.ResponseWriter, r *http.Request) {
	_, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	if err := r.ParseMultipartForm(20 << 20); err != nil {
		http.Error(w, "file too large", http.StatusBadRequest)
		return
	}
	file, header, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "no file", http.StatusBadRequest)
		return
	}
	defer file.Close()
	ext := filepath.Ext(header.Filename)
	if len(ext) > 10 {
		ext = ext[:10]
	}
	name := fmt.Sprintf("%s_%d%s", strings.ReplaceAll(uuid.New().String(), "-", ""), time.Now().Unix(), ext)
	outPath := filepath.Join(h.config.UploadDir, name)
	out, err := createFile(outPath)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	defer out.Close()
	if _, err := io.Copy(out, file); err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	url := "/uploads/" + name
	writeJSON(w, http.StatusOK, map[string]string{"url": url})
}

// separate for permissions; os.Create with 0644
func createFile(path string) (*os.File, error) {
	return os.OpenFile(path, os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0644)
}
