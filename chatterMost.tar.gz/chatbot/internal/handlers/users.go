package handlers

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/acme/realtime-chat/internal/auth"
)

type profileResponse struct {
	ID        string  `json:"id"`
	Username  string  `json:"username"`
	Email     string  `json:"email"`
	AvatarURL *string `json:"avatar_url,omitempty"`
}

type updateProfileRequest struct {
	Username  *string `json:"username,omitempty"`
	AvatarURL *string `json:"avatar_url,omitempty"`
}

func (h *Handlers) SearchUsers(w http.ResponseWriter, r *http.Request) {
	_, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	q := r.URL.Query().Get("query")
	if q == "" {
		writeJSON(w, http.StatusOK, []any{})
		return
	}
	ctx := context.Background()
	rows, err := h.pool.Query(ctx, `SELECT id, username, email FROM users WHERE username ILIKE '%'||$1||'%' OR email ILIKE '%'||$1||'%' ORDER BY username LIMIT 20`, q)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var res []map[string]any
	for rows.Next() {
		var id, username, email string
		if err := rows.Scan(&id, &username, &email); err == nil {
			res = append(res, map[string]any{"id": id, "username": username, "email": email})
		}
	}
	writeJSON(w, http.StatusOK, res)
}

func (h *Handlers) GetProfile(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	ctx := context.Background()
	var username, email string
	var avatar *string
	err := h.pool.QueryRow(ctx, `SELECT username, email, avatar_url FROM users WHERE id=$1`, userID).Scan(&username, &email, &avatar)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	writeJSON(w, http.StatusOK, profileResponse{ID: userID.String(), Username: username, Email: email, AvatarURL: avatar})
}

func (h *Handlers) UpdateProfile(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	var req updateProfileRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	if req.Username != nil {
		_, _ = h.pool.Exec(ctx, `UPDATE users SET username=$1 WHERE id=$2`, *req.Username, userID)
	}
	if req.AvatarURL != nil {
		_, _ = h.pool.Exec(ctx, `UPDATE users SET avatar_url=$1 WHERE id=$2`, *req.AvatarURL, userID)
	}
	h.GetProfile(w, r)
}
