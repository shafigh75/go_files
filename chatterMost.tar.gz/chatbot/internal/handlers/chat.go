package handlers

import (
	"context"
	"encoding/json"
	"net/http"
	"strconv"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"

	"github.com/acme/realtime-chat/internal/auth"
	"github.com/acme/realtime-chat/internal/ws"
)

type createConversationRequest struct {
	ParticipantIDs []string `json:"participant_ids"`
	Name           string   `json:"name"`
}

func (h *Handlers) CreateConversation(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	var req createConversationRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	if len(req.ParticipantIDs) == 0 {
		http.Error(w, "participants required", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	var convID uuid.UUID
	err := h.pool.QueryRow(ctx, `INSERT INTO conversations(is_group, name) VALUES($1,$2) RETURNING id`, len(req.ParticipantIDs) > 1, req.Name).Scan(&convID)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	// add creator
	_, _ = h.pool.Exec(ctx, `INSERT INTO conversation_participants(conversation_id, user_id) VALUES($1,$2) ON CONFLICT DO NOTHING`, convID, userID)
	for _, sid := range req.ParticipantIDs {
		uid, err := uuid.Parse(sid)
		if err != nil {
			continue
		}
		_, _ = h.pool.Exec(ctx, `INSERT INTO conversation_participants(conversation_id, user_id) VALUES($1,$2) ON CONFLICT DO NOTHING`, convID, uid)
	}

	// Notify all participants about the new conversation
	participants := append(req.ParticipantIDs, userID.String())
	for _, sid := range participants {
		uid, err := uuid.Parse(sid)
		if err != nil {
			continue
		}

		// Get conversation details for the notification
		var title string
		var avatar *string
		err = h.pool.QueryRow(ctx, `
			SELECT COALESCE(NULLIF(c.name,''), (
				SELECT u.username FROM conversation_participants p2
				JOIN users u ON u.id = p2.user_id
				WHERE p2.conversation_id = c.id AND p2.user_id <> $1
				LIMIT 1
			)) AS title,
			(
				SELECT u.avatar_url FROM conversation_participants p2
				JOIN users u ON u.id = p2.user_id
				WHERE p2.conversation_id = c.id AND p2.user_id <> $1
				LIMIT 1
			) AS avatar_url
			FROM conversations c
			WHERE c.id = $2
		`, uid, convID).Scan(&title, &avatar)

		if err != nil {
			continue
		}

		payload := map[string]any{
			"type":            "conversation.new",
			"conversation_id": convID,
			"title":           title,
			"is_group":        len(req.ParticipantIDs) > 1,
		}
		if avatar != nil {
			payload["avatar_url"] = *avatar
		}

		h.hub.Emit(uid, payload)
	}

	writeJSON(w, http.StatusCreated, map[string]any{"id": convID})
}

func (h *Handlers) ListConversations(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	ctx := context.Background()
	rows, err := h.pool.Query(ctx, `
		SELECT c.id, c.is_group,
			COALESCE(NULLIF(c.name,''), (
				SELECT u.username FROM conversation_participants p2
				JOIN users u ON u.id = p2.user_id
				WHERE p2.conversation_id = c.id AND p2.user_id <> $1
				LIMIT 1
			)) AS title,
			(
				SELECT u.avatar_url FROM conversation_participants p2
				JOIN users u ON u.id = p2.user_id
				WHERE p2.conversation_id = c.id AND p2.user_id <> $1
				LIMIT 1
			) AS avatar_url,
			COALESCE((
				SELECT COUNT(*) FROM messages m 
				WHERE m.conversation_id = c.id 
				AND m.deleted_at IS NULL 
				AND m.sender_id <> $1
				AND m.created_at > COALESCE((
					SELECT last_read_at FROM user_conversation_reads 
					WHERE user_id = $1 AND conversation_id = c.id
				), '1970-01-01'::timestamptz)
			), 0) AS unread_count
		FROM conversations c
		JOIN conversation_participants p ON p.conversation_id = c.id
		WHERE p.user_id = $1
		ORDER BY c.created_at DESC`, userID)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var res []map[string]any
	for rows.Next() {
		var id uuid.UUID
		var isGroup bool
		var title string
		var avatar *string
		var unreadCount int
		if err := rows.Scan(&id, &isGroup, &title, &avatar, &unreadCount); err == nil {
			m := map[string]any{"id": id, "is_group": isGroup, "title": title, "unread_count": unreadCount}
			if avatar != nil {
				m["avatar_url"] = *avatar
			}
			res = append(res, m)
		}
	}
	writeJSON(w, http.StatusOK, res)
}

func (h *Handlers) ListMessages(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	convIDStr := r.URL.Query().Get("conversation_id")
	if convIDStr == "" {
		http.Error(w, "conversation_id required", http.StatusBadRequest)
		return
	}
	_, err := uuid.Parse(convIDStr)
	if err != nil {
		http.Error(w, "bad conversation_id", http.StatusBadRequest)
		return
	}
	limitStr := r.URL.Query().Get("limit")
	if limitStr == "" {
		limitStr = "50"
	}
	limit, _ := strconv.Atoi(limitStr)
	ctx := context.Background()
	rows, err := h.pool.Query(ctx, `
		SELECT m.id, m.sender_id, m.content, m.media_url, m.created_at
		FROM messages m
		WHERE m.deleted_at IS NULL AND m.conversation_id=$1 AND EXISTS(
			SELECT 1 FROM conversation_participants p WHERE p.conversation_id=$1 AND p.user_id=$2
		)
		ORDER BY m.created_at DESC LIMIT $3`, convIDStr, userID, limit)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var res []map[string]any
	for rows.Next() {
		var id, sid uuid.UUID
		var content, media *string
		var created time.Time
		if err := rows.Scan(&id, &sid, &content, &media, &created); err == nil {
			m := map[string]any{"id": id, "sender_id": sid, "created_at": created}
			if content != nil {
				m["content"] = *content
			}
			if media != nil {
				m["media_url"] = *media
			}
			res = append(res, m)
		}
	}
	writeJSON(w, http.StatusOK, res)
}

func (h *Handlers) Websocket(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	h.hub.ServeWS(w, r, userID)
}

// Dispatch is used by WS hub after persisting
func (h *Handlers) DispatchMessage(msg ws.MessageEvent) {
	// Currently unused, hub broadcasts directly
}

func (h *Handlers) DeleteMessage(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	msgIDStr := chi.URLParam(r, "id")
	msgID, err := uuid.Parse(msgIDStr)
	if err != nil {
		http.Error(w, "bad id", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	// ensure user owns the message and is in conversation; fetch conv id
	var convID uuid.UUID
	err = h.pool.QueryRow(ctx, `
		UPDATE messages m SET deleted_at = now()
		FROM conversation_participants p
		WHERE m.id=$1 AND m.sender_id=$2 AND p.conversation_id=m.conversation_id AND p.user_id=$2
		RETURNING m.conversation_id
	`, msgID, userID).Scan(&convID)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	// broadcast deletion to participants
	rows, err := h.pool.Query(ctx, `SELECT user_id FROM conversation_participants WHERE conversation_id=$1`, convID)
	if err == nil {
		defer rows.Close()
		payload := map[string]any{"type": "message.deleted", "id": msgID, "conversation_id": convID}
		for rows.Next() {
			var pid uuid.UUID
			if err := rows.Scan(&pid); err == nil {
				h.hub.Emit(pid, payload)
			}
		}
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *Handlers) DeleteConversation(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	convIDStr := chi.URLParam(r, "id")
	convID, err := uuid.Parse(convIDStr)
	if err != nil {
		http.Error(w, "bad id", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	// verify membership and capture participants
	rows, err := h.pool.Query(ctx, `SELECT user_id FROM conversation_participants WHERE conversation_id=$1`, convID)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	defer rows.Close()
	var participants []uuid.UUID
	var isMember bool
	for rows.Next() {
		var pid uuid.UUID
		if err := rows.Scan(&pid); err == nil {
			participants = append(participants, pid)
			if pid == userID {
				isMember = true
			}
		}
	}
	if !isMember {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	// delete conversation if requester is participant
	ct, err := h.pool.Exec(ctx, `DELETE FROM conversations WHERE id=$1`, convID)
	if err != nil || ct.RowsAffected() == 0 {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	// broadcast to participants
	payload := map[string]any{"type": "conversation.deleted", "conversation_id": convID}
	for _, pid := range participants {
		h.hub.Emit(pid, payload)
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *Handlers) MarkConversationRead(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	convIDStr := chi.URLParam(r, "id")
	convID, err := uuid.Parse(convIDStr)
	if err != nil {
		http.Error(w, "bad id", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	// Verify user is in conversation
	var exists bool
	err = h.pool.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM conversation_participants WHERE conversation_id=$1 AND user_id=$2)`, convID, userID).Scan(&exists)
	if err != nil || !exists {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	// Upsert read timestamp
	_, err = h.pool.Exec(ctx, `
		INSERT INTO user_conversation_reads(user_id, conversation_id, last_read_at) 
		VALUES($1, $2, now()) 
		ON CONFLICT(user_id, conversation_id) 
		DO UPDATE SET last_read_at = now()`, userID, convID)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *Handlers) DebugUnreadCount(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	convIDStr := r.URL.Query().Get("conversation_id")
	if convIDStr == "" {
		http.Error(w, "conversation_id required", http.StatusBadRequest)
		return
	}
	convID, err := uuid.Parse(convIDStr)
	if err != nil {
		http.Error(w, "bad conversation_id", http.StatusBadRequest)
		return
	}

	ctx := context.Background()

	// Get total messages
	var totalMessages int
	err = h.pool.QueryRow(ctx, `
		SELECT COUNT(*) FROM messages m 
		WHERE m.conversation_id = $1 AND m.deleted_at IS NULL`, convID).Scan(&totalMessages)
	if err != nil {
		http.Error(w, "db error", http.StatusInternalServerError)
		return
	}

	// Get messages from others
	var otherMessages int
	err = h.pool.QueryRow(ctx, `
		SELECT COUNT(*) FROM messages m 
		WHERE m.conversation_id = $1 AND m.deleted_at IS NULL AND m.sender_id <> $2`, convID, userID).Scan(&otherMessages)
	if err != nil {
		http.Error(w, "db error", http.StatusInternalServerError)
		return
	}

	// Get last read time
	var lastRead *time.Time
	err = h.pool.QueryRow(ctx, `
		SELECT last_read_at FROM user_conversation_reads 
		WHERE user_id = $1 AND conversation_id = $2`, userID, convID).Scan(&lastRead)
	if err != nil && err.Error() != "no rows in result set" {
		http.Error(w, "db error", http.StatusInternalServerError)
		return
	}

	// Calculate unread
	var unreadCount int
	if lastRead == nil {
		unreadCount = otherMessages
	} else {
		err = h.pool.QueryRow(ctx, `
			SELECT COUNT(*) FROM messages m 
			WHERE m.conversation_id = $1 AND m.deleted_at IS NULL AND m.sender_id <> $2 AND m.created_at > $3`,
			convID, userID, *lastRead).Scan(&unreadCount)
		if err != nil {
			http.Error(w, "db error", http.StatusInternalServerError)
			return
		}
	}

	debug := map[string]any{
		"conversation_id": convID,
		"user_id":         userID,
		"total_messages":  totalMessages,
		"other_messages":  otherMessages,
		"last_read":       lastRead,
		"unread_count":    unreadCount,
	}

	writeJSON(w, http.StatusOK, debug)
}
