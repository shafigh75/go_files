package handlers

import "net/http"

func requireAuth(w http.ResponseWriter, ok bool) bool {
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return false
	}
	return true
}
