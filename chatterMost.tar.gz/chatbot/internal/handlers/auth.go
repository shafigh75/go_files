package handlers

import (
	"context"
	"encoding/json"
	"net/http"
	"time"

	"github.com/google/uuid"

	"github.com/acme/realtime-chat/internal/auth"
)

type registerRequest struct {
	Username string `json:"username"`
	Email    string `json:"email"`
	Password string `json:"password"`
}

type loginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type userResponse struct {
	ID        uuid.UUID `json:"id"`
	Username  string    `json:"username"`
	Email     string    `json:"email"`
	AvatarURL *string   `json:"avatar_url,omitempty"`
}

func (h *Handlers) Register(w http.ResponseWriter, r *http.Request) {
	var req registerRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid body", http.StatusBadRequest)
		return
	}
	if req.Username == "" || req.Email == "" || req.Password == "" {
		http.Error(w, "missing fields", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	passwordHash, err := auth.HashPassword(req.Password)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	var id uuid.UUID
	err = h.pool.QueryRow(ctx,
		`INSERT INTO users(username, email, password_hash) VALUES($1,$2,$3) RETURNING id`,
		req.Username, req.Email, passwordHash,
	).Scan(&id)
	if err != nil {
		http.Error(w, "could not create user", http.StatusBadRequest)
		return
	}
	issueTokenAndWriteCookie(w, id, h.config.JWTSecret)
	var avatar *string
	writeJSON(w, http.StatusCreated, userResponse{ID: id, Username: req.Username, Email: req.Email, AvatarURL: avatar})
}

func (h *Handlers) Login(w http.ResponseWriter, r *http.Request) {
	var req loginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid body", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	var id uuid.UUID
	var username, passwordHash string
	var avatar *string
	err := h.pool.QueryRow(ctx, `SELECT id, username, password_hash, avatar_url FROM users WHERE email=$1`, req.Email).Scan(&id, &username, &passwordHash, &avatar)
	if err != nil {
		http.Error(w, "invalid credentials", http.StatusUnauthorized)
		return
	}
	ok, err := auth.VerifyPassword(passwordHash, req.Password)
	if err != nil || !ok {
		http.Error(w, "invalid credentials", http.StatusUnauthorized)
		return
	}
	issueTokenAndWriteCookie(w, id, h.config.JWTSecret)
	writeJSON(w, http.StatusOK, userResponse{ID: id, Username: username, Email: req.Email, AvatarURL: avatar})
}

func (h *Handlers) Logout(w http.ResponseWriter, r *http.Request) {
	cookie := &http.Cookie{
		Name:     "auth_token",
		Value:    "",
		MaxAge:   -1,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	}
	http.SetCookie(w, cookie)
	w.WriteHeader(http.StatusNoContent)
}

func (h *Handlers) Me(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	ctx := context.Background()
	var username, email string
	var avatar *string
	err := h.pool.QueryRow(ctx, `SELECT username, email, avatar_url FROM users WHERE id=$1`, userID).Scan(&username, &email, &avatar)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	writeJSON(w, http.StatusOK, userResponse{ID: userID, Username: username, Email: email, AvatarURL: avatar})
}

func issueTokenAndWriteCookie(w http.ResponseWriter, userID uuid.UUID, secret string) {
	tokenStr, _ := auth.CreateJWT(userID, secret, 24*time.Hour)
	cookie := &http.Cookie{
		Name:     "auth_token",
		Value:    tokenStr,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	}
	http.SetCookie(w, cookie)
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
