package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/acme/realtime-chat/internal/auth"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
)

// (removed duplicate import block)

// Delete a channel (only creator)
func (h *Handlers) DeleteChannel(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/api/channels/")
	channelID, err := uuid.Parse(idStr)
	if err != nil {
		http.Error(w, "bad id", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	var creatorID uuid.UUID
	err = h.pool.QueryRow(ctx, `SELECT creator_id FROM channels WHERE id=$1`, channelID).Scan(&creatorID)
	if err != nil {
		http.Error(w, "channel not found", http.StatusNotFound)
		return
	}
	if creatorID != userID {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	// Delete channel (CASCADE will remove posts/subscribers)
	_, err = h.pool.Exec(ctx, `DELETE FROM channels WHERE id=$1`, channelID)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

type createChannelRequest struct {
	Name        string  `json:"name"`
	Description *string `json:"description"`
}

type channelResponse struct {
	ID           uuid.UUID `json:"id"`
	Name         string    `json:"name"`
	Description  *string   `json:"description,omitempty"`
	CreatorID    uuid.UUID `json:"creator_id"`
	CreatedAt    string    `json:"created_at"`
	IsSubscribed bool      `json:"is_subscribed"`
}

type channelPostResponse struct {
	ID        uuid.UUID `json:"id"`
	ChannelID uuid.UUID `json:"channel_id"`
	SenderID  uuid.UUID `json:"sender_id"`
	Content   *string   `json:"content,omitempty"`
	MediaURL  *string   `json:"media_url,omitempty"`
	CreatedAt string    `json:"created_at"`
}

// Create a new channel (only creator can post)
func (h *Handlers) CreateChannel(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	var req createChannelRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Name == "" {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	var id uuid.UUID
	err := h.pool.QueryRow(ctx, `INSERT INTO channels(name, description, creator_id) VALUES($1,$2,$3) RETURNING id`, req.Name, req.Description, userID).Scan(&id)
	if err != nil {
		// Check for duplicate name error (unique constraint)
		if strings.Contains(err.Error(), "duplicate key value") || strings.Contains(err.Error(), "unique constraint") {
			http.Error(w, "Channel name already exists.", http.StatusConflict)
			return
		}
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	// Auto-subscribe creator
	_, _ = h.pool.Exec(ctx, `INSERT INTO channel_subscribers(channel_id, user_id) VALUES($1,$2) ON CONFLICT DO NOTHING`, id, userID)

	// Ensure channel is immediately visible in search for creator
	// (no-op: already visible, but force reload for client)
	writeJSON(w, http.StatusCreated, map[string]any{"id": id})
}

// List/search channels
func (h *Handlers) ListChannels(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	q := r.URL.Query().Get("query")
	ctx := context.Background()
	var rows pgx.Rows
	var err error
	if q != "" {
		// If query starts with #, strip it for channel search
		searchQ := q
		if strings.HasPrefix(searchQ, "#") {
			searchQ = searchQ[1:]
		}
		// For search, show all matching channels, but mark is_subscribed true only if user is creator or subscriber
		rows, err = h.pool.Query(ctx, `
							  SELECT c.id::text, c.name, c.description, c.creator_id::text, c.created_at,
									  (EXISTS(SELECT 1 FROM channel_subscribers s WHERE s.channel_id=c.id AND s.user_id=$2) OR c.creator_id=$2) as is_subscribed
							  FROM channels c
							  WHERE (c.name ILIKE '%'||$1||'%')
							  ORDER BY c.created_at DESC LIMIT 20
					  `, searchQ, userID)
	} else {
		// Only channels user owns or is subscribed to
		rows, err = h.pool.Query(ctx, `
					   SELECT c.id, c.name, c.description, c.creator_id, c.created_at,
							   EXISTS(SELECT 1 FROM channel_subscribers s WHERE s.channel_id=c.id AND s.user_id=$1)
					   FROM channels c
					   WHERE c.creator_id=$1 OR EXISTS(SELECT 1 FROM channel_subscribers s WHERE s.channel_id=c.id AND s.user_id=$1)
					   ORDER BY c.created_at DESC LIMIT 50
			   `, userID)
	}
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var res []channelResponse
	for rows.Next() {
		var c channelResponse
		var createdAt time.Time
		err := rows.Scan(&c.ID, &c.Name, &c.Description, &c.CreatorID, &createdAt, &c.IsSubscribed)
		if err != nil {
			// Log error for debugging
			http.Error(w, "row scan error: "+err.Error(), http.StatusInternalServerError)
			return
		}
		c.CreatedAt = createdAt.Format(time.RFC3339)
		res = append(res, c)
	}
	// Always return 200 with an array, even if empty
	writeJSON(w, http.StatusOK, res)
}

// Subscribe to a channel
func (h *Handlers) SubscribeChannel(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/api/channels/")
	idStr = strings.TrimSuffix(idStr, "/subscribe")
	channelID, err := uuid.Parse(idStr)
	if err != nil {
		http.Error(w, "bad id", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	_, err = h.pool.Exec(ctx, `INSERT INTO channel_subscribers(channel_id, user_id) VALUES($1,$2) ON CONFLICT DO NOTHING`, channelID, userID)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// Unsubscribe from a channel
func (h *Handlers) UnsubscribeChannel(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/api/channels/")
	idStr = strings.TrimSuffix(idStr, "/unsubscribe")
	channelID, err := uuid.Parse(idStr)
	if err != nil {
		http.Error(w, "bad id", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	_, err = h.pool.Exec(ctx, `DELETE FROM channel_subscribers WHERE channel_id=$1 AND user_id=$2`, channelID, userID)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// List posts in a channel (only for subscribers)
func (h *Handlers) ListChannelPosts(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	channelIDStr := r.URL.Query().Get("channel_id")
	if channelIDStr == "" {
		http.Error(w, "channel_id required", http.StatusBadRequest)
		return
	}
	channelID, err := uuid.Parse(channelIDStr)
	if err != nil {
		http.Error(w, "bad channel_id", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	// Allow creator to read posts even if not subscribed
	var creatorID uuid.UUID
	err = h.pool.QueryRow(ctx, `SELECT creator_id FROM channels WHERE id=$1`, channelID).Scan(&creatorID)
	if err != nil {
		http.Error(w, "channel not found", http.StatusNotFound)
		return
	}
	// Always allow creator to view posts, even if not subscribed
	if creatorID != userID {
		var exists bool
		err = h.pool.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM channel_subscribers WHERE channel_id=$1 AND user_id=$2)`, channelID, userID).Scan(&exists)
		if err != nil || !exists {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
	}
	rows, err := h.pool.Query(ctx, `SELECT id, channel_id, sender_id, content, media_url, created_at FROM channel_posts WHERE channel_id=$1 ORDER BY created_at DESC LIMIT 100`, channelID)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	defer rows.Close()
	var res []channelPostResponse
	for rows.Next() {
		var p channelPostResponse
		var createdAt time.Time
		if err := rows.Scan(&p.ID, &p.ChannelID, &p.SenderID, &p.Content, &p.MediaURL, &createdAt); err == nil {
			p.CreatedAt = createdAt.Format(time.RFC3339)
			res = append(res, p)
		}
	}
	// Debug: print length and sample data
	fmt.Printf("[ListChannelPosts] channel_id=%s user_id=%s posts=%d sample=%#v\n", channelID, userID, len(res), func() any {
		if len(res) > 0 {
			return res[0]
		} else {
			return nil
		}
	}())
	writeJSON(w, http.StatusOK, res)
}

// Post to channel (only creator)
func (h *Handlers) PostToChannel(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	idStr := strings.TrimPrefix(r.URL.Path, "/api/channels/")
	idStr = strings.TrimSuffix(idStr, "/post")
	channelID, err := uuid.Parse(idStr)
	if err != nil {
		http.Error(w, "bad id", http.StatusBadRequest)
		return
	}
	ctx := context.Background()
	var creatorID uuid.UUID
	err = h.pool.QueryRow(ctx, `SELECT creator_id FROM channels WHERE id=$1`, channelID).Scan(&creatorID)
	if err != nil || creatorID != userID {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}
	var req struct {
		Content  *string `json:"content"`
		MediaURL *string `json:"media_url"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	var id uuid.UUID
	var createdAt time.Time
	err = h.pool.QueryRow(ctx, `INSERT INTO channel_posts(channel_id, sender_id, content, media_url) VALUES($1,$2,$3,$4) RETURNING id, created_at`, channelID, userID, req.Content, req.MediaURL).Scan(&id, &createdAt)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}
	// Broadcast to all subscribers and creator via WebSocket
	ev := map[string]any{
		"type":       "channel.post.new",
		"id":         id,
		"channel_id": channelID,
		"sender_id":  userID,
		"content":    req.Content,
		"media_url":  req.MediaURL,
		"created_at": createdAt.Format(time.RFC3339),
	}
	// Get all subscribers and creator
	rows, err := h.pool.Query(ctx, `SELECT user_id FROM channel_subscribers WHERE channel_id=$1 UNION SELECT creator_id FROM channels WHERE id=$1`, channelID)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var uid uuid.UUID
			if err := rows.Scan(&uid); err == nil {
				h.hub.Emit(uid, ev)
			}
		}
	}
	writeJSON(w, http.StatusCreated, map[string]any{"id": id})
}

// Delete a channel post (only creator)
func (h *Handlers) DeleteChannelPost(w http.ResponseWriter, r *http.Request) {
	userID, ok := auth.UserIDFromRequest(r, h.config.JWTSecret)
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}

	// Extract post ID from URL path
	pathParts := strings.Split(r.URL.Path, "/")
	if len(pathParts) < 4 {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	postID, err := uuid.Parse(pathParts[len(pathParts)-1])
	if err != nil {
		http.Error(w, "bad post id", http.StatusBadRequest)
		return
	}

	ctx := context.Background()

	// Check if user is the creator of the channel that contains this post
	var channelID uuid.UUID
	err = h.pool.QueryRow(ctx, `SELECT channel_id FROM channel_posts WHERE id = $1`, postID).Scan(&channelID)
	if err != nil {
		http.Error(w, "post not found", http.StatusNotFound)
		return
	}

	// Verify user is the channel creator
	var creatorID uuid.UUID
	err = h.pool.QueryRow(ctx, `SELECT creator_id FROM channels WHERE id = $1`, channelID).Scan(&creatorID)
	if err != nil || creatorID != userID {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	// Delete the post
	_, err = h.pool.Exec(ctx, `DELETE FROM channel_posts WHERE id = $1`, postID)
	if err != nil {
		http.Error(w, "server error", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)

	// Broadcast deletion to all subscribers and creator via WebSocket
	ev := map[string]any{
		"type":       "channel.post.deleted",
		"id":         postID,
		"channel_id": channelID,
	}
	// Get all subscribers and creator
	rows, err := h.pool.Query(ctx, `SELECT user_id FROM channel_subscribers WHERE channel_id=$1 UNION SELECT creator_id FROM channels WHERE id=$1`, channelID)
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var uid uuid.UUID
			if err := rows.Scan(&uid); err == nil {
				h.hub.Emit(uid, ev)
			}
		}
	}
}
