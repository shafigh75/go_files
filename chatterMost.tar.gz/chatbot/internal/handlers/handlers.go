package handlers

import (
	"net/http"
	"os"

	"github.com/acme/realtime-chat/internal/config"
	"github.com/acme/realtime-chat/internal/ws"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Handlers struct {
	pool   *pgxpool.Pool
	hub    *ws.Hub
	config config.Config
}

func New(pool *pgxpool.Pool, hub *ws.Hub, cfg config.Config) *Handlers {
	return &Handlers{pool: pool, hub: hub, config: cfg}
}

func (h *Handlers) Index(w http.ResponseWriter, r *http.Request) {
	data, err := os.ReadFile("web/templates/index.html")
	if err != nil {
		http.Error(w, "template not found", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(data)
}
