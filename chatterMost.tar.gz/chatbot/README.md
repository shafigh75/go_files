# Realtime Chat Application

A full-featured real-time chat application built with Go, PostgreSQL, WebSocket, Alpine.js, and Tailwind CSS.

## Features

### Authentication
- JWT-based authentication (register/login/logout)
- Secure password hashing
- Session management with HTTP-only cookies

### Messaging
- Real-time messaging via WebSocket
- 1:1 and group conversations
- Message history with pagination
- Media uploads (images, documents, etc.)
- Message deletion (user can delete their own messages)
- Conversation deletion (removes for all participants)
- Unread message tracking

### Channels
- Telegram-style channels (read-only except for creator)
- Channel creation and management
- Channel subscription/unsubscription
- Channel post creation and deletion (creator only)
- Channel search functionality

### User Management
- User profile management (username, avatar)
- User search by username or email
- Avatar support with file upload

### UI/UX
- Modern, responsive interface with dark/light mode
- Real-time notifications
- Unread message badges
- Smooth animations and transitions
- Mobile-friendly design

### Technical
- PostgreSQL database with proper indexing
- Database migrations
- Docker support for easy deployment
- RESTful API design
- Clean architecture with separation of concerns

## Tech Stack

- **Backend**: Go, PostgreSQL, WebSocket
- **Frontend**: Alpine.js, Tailwind CSS (CDN), HTML5
- **Authentication**: JWT
- **Deployment**: Docker, Docker Compose

## Run with Docker (Recommended)

```bash
docker compose up --build
```

The application will be available at: http://localhost:8080

## Run Locally

1. Ensure you have Go 1.22+ and PostgreSQL installed
2. Set up the database:
   ```bash
   createdb chatapp
   ```
3. Configure environment variables:
   ```bash
   export DATABASE_URL=postgres://postgres:postgres@localhost:5432/chatapp?sslmode=disable
   export JWT_SECRET=your-secret-key
   export UPLOAD_DIR=./uploads
   ```
4. Run the application:
   ```bash
   go mod tidy
   go run ./cmd/server
   ```

## API Endpoints

### Authentication
- `POST /api/register` - Register a new user
- `POST /api/login` - Login
- `POST /api/logout` - Logout
- `GET /api/me` - Get current user info

### Users
- `GET /api/users` - Search users
- `GET /api/profile` - Get user profile
- `PUT /api/profile` - Update user profile

### Conversations
- `GET /api/conversations` - List user's conversations
- `POST /api/conversations` - Create a new conversation
- `DELETE /api/conversations/{id}` - Delete a conversation
- `PUT /api/conversations/{id}/read` - Mark conversation as read

### Messages
- `GET /api/messages` - List messages in a conversation
- `DELETE /api/messages/{id}` - Delete a message

### Channels
- `POST /api/channels` - Create a new channel
- `GET /api/channels` - List/search channels
- `DELETE /api/channels/{id}` - Delete a channel
- `POST /api/channels/{id}/subscribe` - Subscribe to a channel
- `POST /api/channels/{id}/unsubscribe` - Unsubscribe from a channel
- `GET /api/channels/posts` - List posts in a channel
- `POST /api/channels/{id}/post` - Post to a channel
- `DELETE /api/channels/posts/{id}` - Delete a channel post

### Media
- `POST /api/upload` - Upload media files

### WebSocket
- `GET /ws` - WebSocket connection for real-time messaging

## Project Structure

```
.
├── cmd/server/          # Main application entry point
├── db/migrations/       # Database migration files
├── internal/
│   ├── auth/           # Authentication logic
│   ├── config/         # Configuration management
│   ├── db/             # Database utilities
│   ├── handlers/       # HTTP handlers
│   └── ws/             # WebSocket implementation
├── web/
│   ├── src/            # Frontend assets
│   └── templates/      # HTML templates
├── uploads/            # Uploaded media files (when running locally)
├── Dockerfile          # Docker configuration
├── docker-compose.yml # Docker Compose configuration
└── go.mod             # Go module dependencies
```

## Database Schema

The application uses PostgreSQL with the following key tables:
- `users` - User accounts
- `conversations` - Chat conversations
- `conversation_participants` - Links users to conversations
- `messages` - Individual chat messages
- `channels` - Public channels
- `channel_subscribers` - Links users to channels
- `channel_posts` - Posts within channels
- `user_conversation_reads` - Tracks read status of conversations

## Development

### Available Make Commands
- `make dev` - Run the application in development mode
- `make build` - Build the application binary
- `make lint` - Format code with gofmt

### Frontend Development
The frontend is built with Alpine.js for reactivity and Tailwind CSS for styling. All frontend assets are served directly by the Go application.

## Deployment

The application can be deployed using Docker. For production, ensure you:
1. Change the JWT secret to a secure random value
2. Use a proper PostgreSQL database
3. Configure appropriate environment variables
4. Set up a reverse proxy (nginx, etc.) for HTTPS

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License.
