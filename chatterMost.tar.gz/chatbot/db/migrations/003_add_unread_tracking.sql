-- Track when users last read each conversation
CREATE TABLE IF NOT EXISTS user_conversation_reads (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    last_read_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, conversation_id)
);

-- Add index for efficient unread count queries
CREATE INDEX IF NOT EXISTS idx_user_conversation_reads_user_id ON user_conversation_reads (user_id);
CREATE INDEX IF NOT EXISTS idx_user_conversation_reads_conversation_id ON user_conversation_reads (conversation_id); 