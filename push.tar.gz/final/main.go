package main

import (
	"bytes"
	"database/sql"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"sync"

	_ "github.com/go-sql-driver/mysql"
)

type Server struct {
	db *sql.DB
}

type PageData struct {
	Success bool
}

func main() {
	// Set up logging to a file
	logFile, err := os.OpenFile("push_notifications.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Fatal(err)
	}
	defer logFile.Close()
	log.SetOutput(logFile)
	log.SetFlags(log.LstdFlags | log.Lshortfile)

	dsn := "appserver:@tcp(172.16.9.133:3306)/DB1"
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	Server := Server{
		db: db,
	}
	http.HandleFunc("/", Server.formHandler)
	http.ListenAndServe(":10200", nil)
}

func (server *Server) formHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		tmpl, err := template.ParseFiles("templates/form.html")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		tmpl.Execute(w, nil)
	} else if r.Method == http.MethodPost {
		r.ParseMultipartForm(10 << 20) // 10 MB limit

		title := r.FormValue("title")
		message := r.FormValue("message")
		link := r.FormValue("link")

		file, _, err := r.FormFile("file")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		defer file.Close()

		os.MkdirAll("users", os.ModePerm)
		dst, err := os.Create(filepath.Join("users", "file.csv"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		defer dst.Close()

		if _, err := io.Copy(dst, file); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		filePath := "users/file.csv"
		sendPushFromExcel(server.db, filePath, title, message, link)

		// Render the success message
		tmpl, err := template.ParseFiles("templates/form.html")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		tmpl.Execute(w, PageData{Success: true})

	}
}

func SendPush(PushTitle string, PushMessage string, PushLink string, PushToken string, Mobile string, Id string) {
	log.Printf("\n---------------NEW_PUSH_REQUEST-----------------\nReceived data:\nTitle: %s\nMessage: %s\nLink: %s\n", PushTitle, PushMessage, PushLink)
	key := "AAAAFp5C9sA:APA91bE3oeh7OfzmfXj0qTPPqqCar9AeZqF0DdLKYBxoyB0qkdDkBgkzRsaS3AdYKiCOKjuCOo_5bLUv9dIFTyCa86SONoy3eFyPSlEy5umFRDQWr2wfFabzZX5Mwibh_gtO7pbntekQ"
	url := "https://fcm.googleapis.com/fcm/send"

	data := fmt.Sprintf(`{
			"to": "%s",
			"notification": {
					"title": "%s",
					"body": "%s",
					"image": "%s",
					"click_action": "general"
			},
			"data": {
					"title": "%s",
					"body": "%s",
					"link": "%s"
			}
	}`, PushToken, PushTitle, PushMessage, "mediaUrl", PushTitle, PushMessage, PushLink)
	requestBody := bytes.NewBuffer([]byte(data))
	req, err := http.NewRequest("POST", url, requestBody)
	if err != nil {
		log.Println("Error creating request:", err)
		return
	}
	req.Header.Set("Authorization", "key="+key)
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Println("Error making request:", err)
		return
	}
	defer resp.Body.Close()
	responseBody, err22 := ioutil.ReadAll(resp.Body)
	if err22 != nil {
		log.Printf("Error reading response body: %v\n", err22)
	}

	var successResponse map[string]any
	err = json.Unmarshal([]byte(string(responseBody)), &successResponse)
	if err == nil {
		log.Println(Mobile, Id, successResponse)
		if successResponse["error"] != nil {
			fmt.Println(Mobile, " Error :", successResponse)
		}
	} else {
		log.Println(Mobile, Id, err)
	}
}

func readMobilesFromCSV(filePath string) ([]string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	reader := csv.NewReader(file)
	records, err := reader.ReadAll()
	if err != nil {
		return nil, err
	}

	var mobiles []string
	for _, record := range records {
		mobiles = append(mobiles, record[0])
	}
	return mobiles, nil
}

func sendPushFromExcel(db *sql.DB, filePath, title, body, link string) {
	mobiles, err := readMobilesFromCSV(filePath)
	if err != nil {
		log.Fatal(err)
	}

	var wg sync.WaitGroup
	var mu sync.Mutex
	sentTokens := make(map[string]bool)

	for _, mobile := range mobiles {
		wg.Add(1)
		go func(mobile string) {
			defer wg.Done()
			var token string
			err := db.QueryRow("SELECT token FROM firebase WHERE mobile = ?", mobile).Scan(&token)
			if err != nil {
				if err == sql.ErrNoRows {
					log.Printf("No token found for mobile: %s\n", mobile)
					return
				}
				log.Fatal(err)
			}

			mu.Lock()
			if !sentTokens[token] {
				sentTokens[token] = true
				mu.Unlock()
				SendPush(title, body, link, token, mobile, "1")
			} else {
				mu.Unlock()
			}
		}(mobile)
	}

	wg.Wait()
}
