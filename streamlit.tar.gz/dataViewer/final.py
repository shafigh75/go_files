import streamlit as st
import mysql.connector
import pandas as pd

# Function to connect to MySQL and retrieve all table names
def get_tables(host, user, password, db_name):
    try:
        # Establish connection
        connection = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=db_name
        )
        cursor = connection.cursor()

        # Fetch all table names
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        table_list = [table[0] for table in tables]

        cursor.close()
        connection.close()
        return table_list

    except mysql.connector.Error as e:
        st.error(f"Error connecting to MySQL: {e}")
        return []

        

def get_table_info(host, user, password, db_name, table_name):
    try:
        # Establish connection
        connection = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=db_name
        )
        cursor = connection.cursor(dictionary=True)

        # Fetch column descriptions
        cursor.execute(f"DESCRIBE {table_name}")
        columns = cursor.fetchall()

        # Fetch a sample of 5 rows from the table
        cursor.execute(f"SELECT * FROM {table_name} LIMIT 10")
        sample_data = cursor.fetchall()

        cursor.close()
        connection.close()

        return columns, pd.DataFrame(sample_data)

    except mysql.connector.Error as e:
        st.error(f"Error fetching data from MySQL: {e}")
        return None, None



# Streamlit app
def main():
    with open("style.css") as css:
        st.markdown(f'<style>{css.read()}</style>', unsafe_allow_html=True)
    # Set page configuration

    st.title("اطلاعات داده های اپلیکیشن شهرمن")

    # User input for multiple database connections
    st.sidebar.header("جزییات اطلاعات دیتابیس")
    # Define the options for the dropdown
    servers = ["mainDB(سرور اصلی)", "clubDB(سرور باشگاه)"]

    # Create the dropdown
    selected_server = st.sidebar.selectbox("دیتابیس مورد نظر را انتخاب کنید", servers)
    
    if selected_server == "mainDB(سرور اصلی)":
        server = {
            "host":"172.16.9.133",
            "user":"appserver",
            "password":"",
            "database":"DB1" 
        }
    else:
        server = {
            "host":"5.252.216.166",
            "user":"bashgah",
            "password":"aTCkHxAQLAK34a3",
            "database":"shahreman_bashgah" 
        }
    
    tables = get_tables(server["host"],server["user"],server["password"],server["database"])
    table = st.sidebar.selectbox("جدول را انتخاب کنید: ",tables)
    columns , data = get_table_info(server["host"],server["user"],server["password"],server["database"],table)
    if columns and data is not None:
        st.subheader(f" نام جدول: {table}")

        # Display columns
        st.write("### توضیحات فیلدهای جدول")
        st.dataframe(pd.DataFrame(columns),use_container_width=True)

        # Display sample data
        st.write("### داده های نمونه")
        st.dataframe(data,use_container_width=True)
        # Run the Streamlit app
    
if __name__ == "__main__":

    main()
