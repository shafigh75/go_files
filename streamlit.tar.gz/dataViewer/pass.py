import streamlit_authenticator as stauth

hashed_passwords = stauth.Hasher(['R@van14o3']).generate()
print(hashed_passwords)