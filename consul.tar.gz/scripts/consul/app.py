from fastapi import FastAPI
import requests

app = FastAPI()

@app.get("/")
async def read_root():
    return {"message": "Hello, World!"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

def register_service():
    service_definition = {
      "ID": "fast",
      "Name": "fastApiMohammad",
      "Tags": ["King", "light", "v1"],
      "Address": "localhost",
      "Port": 8000,
      "Check": {
        "name": "king mohammad on port 8000",
        "tcp": "127.0.0.1:8000",
        "Interval": "30s",
        "timeout": "2s"
      }
    }
    
    response = requests.put("http://localhost:8500/v1/agent/service/register", json=service_definition)
    if response.status_code == 200:
        print("Service registered successfully!")
    else:
        print("Failed to register service:", response.text)

if __name__ == "__main__":
    register_service()  # Register the service when the app starts
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

