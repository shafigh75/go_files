import requests

def get_service_info(service_name):
    # Query Consul for the specified service
    url = f"http://localhost:8500/v1/catalog/service/{service_name}"
    response = requests.get(url)
    
    if response.status_code == 200:
        services = response.json()
        if services:
            for service in services:
                # Assuming the first instance is the one you want
                service_id = service['ServiceID']
                service_address = service['Address']
                service_port = service['ServicePort']
                print(f"Service ID: {service_id}")
                print(f"Service Address: {service_address}")
                print(f"Service Port: {service_port}")
                return service_address , service_port
        else:
            print(f"No instances of service '{service_name}' found.")
            return None
    else:
        print(f"Failed to retrieve service info: {response.text}")
        return None


def sendReq(addr,port):
    response = requests.get(f"http://{addr}:{port}")
    # Check if the request was successful
    if response.status_code == 200:
        # Process the response data (JSON in this example)
        data = response.json()
        print("Response Data:", data)
    else:
        print(f"Error: Received status code {response.status_code}")

if __name__ == "__main__":
    # Example usage
    service_name = "fastApiMohammad"  # Replace with your service name
    addr, port = get_service_info(service_name)
    sendReq(addr,port)
