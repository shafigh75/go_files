import random
import csv
import jdatetime
from datetime import timedelta

# ------------------------------
# تنظیمات
# ------------------------------
mobiles_file = "mobiles.txt"  # فایل موبایل‌ها
output_file = "mock_cleaned_score_view.csv"
num_records = 10000

titles = [
    "شرکت در نظرسنجی",
    "شرکت در مسابقه",
    "ثبت من کارت",
    "درخواست شهروندی 137",
    "دعوت از دوستان",
    "پیاده روی",
    "فعالیت دوچرخه",
    "پرداخت کرایه دوچرخه بایدو",
    "خرید از کیف پول",
    "خرید بلیت مترو",
    "خرید بلیت اتوبوس",
    "پرداخت بدهی الیت",
    "خوداظهاری الیت",
    "پرداخت کرایه تاکسی"
]

statuses = ["فعال", "غیرفعال"]

# ------------------------------
# خواندن موبایل‌ها از فایل
# ------------------------------
with open(mobiles_file, "r", encoding="utf-8") as f:
    mobiles = [line.strip() for line in f if line.strip()]

if not mobiles:
    raise ValueError("❌ فایل موبایل خالی است!")

# ------------------------------
# تابع ساخت تاریخ شمسی تصادفی
# ------------------------------
def random_persian_date():
    start = jdatetime.datetime(1399, 12, 1, 0, 0, 0)
    end = jdatetime.datetime(1404, 3, 22, 23, 59, 59)

    # اختلاف بر حسب ثانیه
    delta_seconds = int((end.togregorian() - start.togregorian()).total_seconds())
    rand_seconds = random.randint(0, delta_seconds)

    # تاریخ تصادفی
    rand_date = start.togregorian() + timedelta(seconds=rand_seconds)
    jdate = jdatetime.datetime.fromgregorian(datetime=rand_date)

    return jdate.strftime("%Y-%m-%d %H:%M:%S")

# ------------------------------
# ساخت داده‌ها
# ------------------------------
records = []
for _ in range(num_records):
    mobile = random.choice(mobiles)
    score = round(random.uniform(1, 100), 1)  # امتیاز بین 1 تا 100
    status = random.choice(statuses)
    created_at_persian = random_persian_date()
    title = random.choice(titles)

    records.append([mobile, score, status, created_at_persian, title])

# ------------------------------
# ذخیره در فایل CSV
# ------------------------------
with open(output_file, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["mobile", "score", "status", "created_at_persian", "title"])
    writer.writerows(records)

print(f"✅ فایل {output_file} با {num_records} رکورد ساخته شد (تاریخ‌ها از 1399-12-01 تا 1404-03-22)")

