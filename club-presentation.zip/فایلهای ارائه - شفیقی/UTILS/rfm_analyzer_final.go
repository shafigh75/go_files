package main

import (
    "encoding/csv"
    "flag"
    "fmt"
    "io"
    "log"
    "os"
    "strconv"
    "strings"
    "time"
    pc "github.com/yaa110/go-persian-calendar"
)

type Record struct {
    Mobile    string
    Score     float64
    Status    string
    CreatedAt time.Time
    Title     string
}

type UserStats struct {
    LastActivity  time.Time
    FirstActivity time.Time
    Frequency     int
    Monetary      float64
}

func parseJalali(datetimeStr string) (time.Time, error) {
    parts := strings.Split(datetimeStr, " ")
    if len(parts) != 2 {
        return time.Time{}, fmt.Errorf("invalid datetime format: %s", datetimeStr)
    }

    dateParts := strings.Split(parts[0], "-")
    if len(dateParts) != 3 {
        return time.Time{}, fmt.Errorf("invalid date: %s", parts[0])
    }

    year, _ := strconv.Atoi(dateParts[0])
    month, _ := strconv.Atoi(dateParts[1])
    day, _ := strconv.Atoi(dateParts[2])

    timeParts := strings.Split(parts[1], ":")
    if len(timeParts) != 3 {
        return time.Time{}, fmt.Errorf("invalid time: %s", parts[1])
    }

    hour, _ := strconv.Atoi(timeParts[0])
    min, _ := strconv.Atoi(timeParts[1])
    sec, _ := strconv.Atoi(timeParts[2])

    jalali := pc.Date(year, pc.Month(month), day, hour, min, sec, 0, time.UTC)
    return jalali.Time(), nil
}

func analyzeCSV(filename string, referenceDate time.Time) (map[string]*UserStats, error) {
    file, err := os.Open(filename)
    if err != nil {
        return nil, err
    }
    defer file.Close()

    reader := csv.NewReader(file)
    reader.FieldsPerRecord = -1
    _, err = reader.Read() // skip header
    if err != nil {
        return nil, err
    }

    users := make(map[string]*UserStats)
    threshold := referenceDate.AddDate(-1, 0, 0)

    for {
        row, err := reader.Read()
        if err == io.EOF {
            break
        }
        if err != nil {
            return nil, err
        }
        if len(row) < 5 {
            continue
        }

        score, err := strconv.ParseFloat(row[1], 64)
        if err != nil {
            log.Printf("warning: invalid score %s", row[1])
            continue
        }

        createdAt, err := parseJalali(row[3])
        if err != nil {
            log.Printf("warning: invalid date %s", row[3])
            continue
        }

        mobile := row[0]
        if _, ok := users[mobile]; !ok {
            users[mobile] = &UserStats{FirstActivity: createdAt, LastActivity: createdAt}
        }
        u := users[mobile]

        if createdAt.Before(u.FirstActivity) {
            u.FirstActivity = createdAt
        }
        if createdAt.After(u.LastActivity) {
            u.LastActivity = createdAt
        }

        if createdAt.After(threshold) && createdAt.Before(referenceDate.AddDate(0, 0, 1)) {
            u.Frequency++
            u.Monetary += score
        }
    }

    return users, nil
}

func writeRFM(filename string, users map[string]*UserStats, referenceDate time.Time) error {
    file, err := os.Create(filename)
    if err != nil {
        return err
    }
    defer file.Close()

    writer := csv.NewWriter(file)
    defer writer.Flush()

    writer.Write([]string{"mobile", "recency_days", "frequency_12mo", "monetary_12mo", "first_activity", "last_activity"})

    for mobile, u := range users {
        recency := int(referenceDate.Sub(u.LastActivity).Hours() / 24)
        writer.Write([]string{
            mobile,
            strconv.Itoa(recency),
            strconv.Itoa(u.Frequency),
            fmt.Sprintf("%.2f", u.Monetary),
            u.FirstActivity.Format("2006-01-02"),
            u.LastActivity.Format("2006-01-02"),
        })
    }
    return nil
}

func writePersona(filename string, users map[string]*UserStats, referenceDate time.Time) error {
    file, err := os.Create(filename)
    if err != nil {
        return err
    }
    defer file.Close()

    writer := csv.NewWriter(file)
    defer writer.Flush()

    writer.Write([]string{"گروه عضویت", "تعریف عملیاتی", "تعداد کاربران", "درصد از کل باشگاه"})

    total := len(users)
    buckets := map[string]int{"new": 0, "mid": 0, "old": 0}

    for _, u := range users {
        days := int(referenceDate.Sub(u.FirstActivity).Hours() / 24)
        if days <= 30 {
            buckets["new"]++
        } else if days <= 180 {
            buckets["mid"]++
        } else {
            buckets["old"]++
        }
    }

    writer.Write([]string{"تازه‌وارد", "≤ ۳۰ روز", strconv.Itoa(buckets["new"]), fmt.Sprintf("%.2f", float64(buckets["new"]*100)/float64(total))})
    writer.Write([]string{"میان‌مدت", "۳۱–۱۸۰ روز", strconv.Itoa(buckets["mid"]), fmt.Sprintf("%.2f", float64(buckets["mid"]*100)/float64(total))})
    writer.Write([]string{"باسابقه", "≥ ۱۸۱ روز", strconv.Itoa(buckets["old"]), fmt.Sprintf("%.2f", float64(buckets["old"]*100)/float64(total))})

    return nil
}

func main() {
    input := flag.String("input", "cleaned_score_view.csv", "Path to input CSV")
    outRFM := flag.String("out_rfm", "rfm_all.csv", "Path to RFM output CSV")
    outPersona := flag.String("out_persona", "persona_summary.csv", "Path to Persona summary CSV")
    flag.Parse()

    referenceDate := time.Now()

    users, err := analyzeCSV(*input, referenceDate)
    if err != nil {
        log.Fatal(err)
    }

    if err := writeRFM(*outRFM, users, referenceDate); err != nil {
        log.Fatal(err)
    }

    if err := writePersona(*outPersona, users, referenceDate); err != nil {
        log.Fatal(err)
    }

    fmt.Println("Analysis complete! Outputs saved.")
}
