import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Step 1: Load the data
file_path = '/home/test/test/tmp/club/RFM/cleaned_score_view.csv'
df = pd.read_csv(file_path)

# Step 2: Prepare the data (only 'score' column, reshape for sklearn)
X = df[['score']].values  # Keep as 2D array for sklearn

# Step 3: Choose number of clusters (you can adjust this)
k = 4  # Example: 3 clusters (e.g., low, medium, high)

# Step 4: Fit K-Means
kmeans = KMeans(n_clusters=k, random_state=42)
df['cluster'] = kmeans.fit_predict(X)

# Step 5: Inspect results
print("Cluster centers (score thresholds):")
for i, center in enumerate(kmeans.cluster_centers_):
    print(f"Cluster {i}: center = {center[0]:.2f}")

print("\nFirst few rows with cluster labels:")
print(df[['mobile', 'score', 'status', 'cluster']].head(10))

# Optional: Plot the clusters (1D histogram colored by cluster)
plt.figure(figsize=(10, 6))
colors = ['red', 'green', 'blue', 'purple', 'orange']  # Extend if k > 5
for i in range(k):
    cluster_data = df[df['cluster'] == i]['score']
    plt.hist(cluster_data, bins=20, alpha=0.6, label=f'Cluster {i}', color=colors[i % len(colors)])

plt.xlabel('Score')
plt.ylabel('Frequency')
plt.title('K-Means Clustering of Scores')
plt.legend()
plt.grid(True)
plt.show()
