################    1
to run app: 
python3 app.py 
then open port 5000 of  your server to use the webApp.

################    
in UTILS folder we have Kmeans-method and RFM extract code + how we randomized the data 

################    
in UTILS folder there are helper files to generate RFM, and how we Randomized our data
plus the k means implementation for clustering

################    
make sure when you run model, you address the csv files correctly to get proper answer.
these files are in DATA folder.

in DATA folder we have all the train data and real data which our model used.