document.addEventListener('DOMContentLoaded', function() {
    const chatInput = document.getElementById('chatInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');
    const emptyState = document.getElementById('emptyState');
    const chatSuggestions = document.getElementById('chatSuggestions');
    const newChatBtn = document.getElementById('newChatBtn');
    const thinkingModal = new bootstrap.Modal(document.getElementById('thinkingModal'));
    
    // Configure marked options
    marked.setOptions({
        breaks: true,
        gfm: true,
        highlight: function(code, lang) {
            if (lang && hljs.getLanguage(lang)) {
                try {
                    return hljs.highlight(code, { language: lang }).value;
                } catch (err) {}
            }
            return hljs.highlightAuto(code).value;
        }
    });
    
    // Function to add a message to the chat
    function addMessage(content, isUser = false) {
        // Hide empty state if visible
        if (!emptyState.classList.contains('d-none')) {
            emptyState.classList.add('d-none');
        }
        
        // Show chat suggestions if not visible
        if (chatSuggestions.classList.contains('d-none')) {
            chatSuggestions.classList.remove('d-none');
        }
        
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message');
        if (isUser) {
            messageDiv.classList.add('user');
        }
        
        const messageContent = document.createElement('div');
        messageContent.classList.add('message-content');
        
        if (isUser) {
            // For user messages, just display as plain text
            messageContent.textContent = content;
        } else {
            // For bot messages, parse as markdown
            const parsedContent = marked.parse(content);
            messageContent.innerHTML = parsedContent;
            
            // Render math expressions
            renderMathInElement(messageContent, {
                delimiters: [
                    {left: '$$', right: '$$', display: true},
                    {left: '$', right: '$', display: false}
                ]
            });
            
            // Highlight code blocks
            messageContent.querySelectorAll('pre code').forEach((block) => {
                hljs.highlightElement(block);
            });
        }
        
        const messageTime = document.createElement('div');
        messageTime.classList.add('message-time');
        const now = new Date();
        messageTime.textContent = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`;
        
        messageContent.appendChild(messageTime);
        messageDiv.appendChild(messageContent);
        chatMessages.appendChild(messageDiv);
        
        // Scroll to the bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Function to show thinking modal
    function showThinkingModal() {
        thinkingModal.show();
    }
    
    // Function to hide thinking modal
    function hideThinkingModal() {
        thinkingModal.hide();
    }
    
    // Function to send a message
    function sendMessage() {
        const message = chatInput.value.trim();
        if (message === '') return;
        
        // Add user message to chat
        addMessage(message, true);
        
        // Clear input
        chatInput.value = '';
        
        // Show thinking modal
        showThinkingModal();
        
        // Send message to backend
        fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Hide thinking modal
            hideThinkingModal();
            
            // Add bot response
            addMessage(data.response);
        })
        .catch(error => {
            // Hide thinking modal
            hideThinkingModal();
            
            // Add error message
            addMessage('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
            console.error('Error:', error);
        });
    }
    
    // Function to populate input with suggestion text
    function populateSuggestion(text) {
        chatInput.value = text;
        // Focus on the input field
        chatInput.focus();
        // Move cursor to the end of the text
        chatInput.setSelectionRange(text.length, text.length);
    }
    
    // Function to start a new chat
    function startNewChat() {
        // Clear all messages
        const messages = chatMessages.querySelectorAll('.message');
        messages.forEach(message => message.remove());
        
        // Show empty state
        emptyState.classList.remove('d-none');
        
        // Hide chat suggestions
        chatSuggestions.classList.add('d-none');
        
        // Clear input
        chatInput.value = '';
        
        // Focus on input
        chatInput.focus();
    }
    
    // Event listeners
    sendButton.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // New chat button
    newChatBtn.addEventListener('click', startNewChat);
    
    // Add event listeners to suggestion buttons
    const suggestionButtons = document.querySelectorAll('.suggestion');
    suggestionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const suggestionText = this.textContent;
            populateSuggestion(suggestionText);
        });
    });
    
    // Make functions available globally if needed
    window.populateSuggestion = populateSuggestion;
    window.startNewChat = startNewChat;
});
