import pandas as pd
import numpy as np
import re
import datetime
import requests
import json
import logging
import subprocess
from typing import Dict, List, Optional, Any
from tqdm import tqdm
from collections import Counter
from pydantic_ai import Agent, Tool

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# -----------------------------
# 1. Load RFM data (small file)
# -----------------------------
def load_rfm_data(file_path: str) -> Dict:
    """Load RFM data from CSV file"""
    logger.info(f"شروع بارگذاری داده‌های RFM از فایل: {file_path}")
    rfm_data = {}

    try:
        df = pd.read_csv(file_path)
        for _, row in df.iterrows():
            rfm_data[row['mobile']] = {
                'recency_days': int(row['recency_days']),
                'frequency_12mo': int(row['frequency_12mo']),
                'monetary_12mo': float(row['monetary_12mo']),
                'first_activity': row['first_activity'],
                'last_activity': row['last_activity']
            }

        logger.info(f"بارگذاری داده‌های RFM با موفقیت انجام شد. {len(rfm_data)} کاربر بارگذاری شد.")

    except Exception as e:
        logger.error(f"خطا در بارگذاری داده‌های RFM: {e}")
        raise

    return rfm_data

# Load RFM data
logger.info("شروع بارگذاری داده‌های RFM...")
rfm_data = load_rfm_data('/home/test/test/agent-club-research/demo_final/rfm_all.csv')
logger.info("داده‌های RFM با موفقیت بارگذاری شدند.")

# -----------------------------
# 2. Functions to get user data on demand
# -----------------------------
def get_rfm_data(mobile: str) -> str:
    """Get RFM data for a user"""
    if mobile in rfm_data:
        data = rfm_data[mobile]
        return f"تازگی: {data['recency_days']} روز، فراوانی: {data['frequency_12mo']} بار، ارزش: {data['monetary_12mo']} امتیاز، اولین فعالیت: {data['first_activity']}, آخرین فعالیت: {data['last_activity']}"
    return "کاربری با این شماره موبایل یافت نشد."

def get_user_behavior_data(mobile: str) -> pd.DataFrame:
    """Get user behavior data using grep to avoid loading entire file"""
    logger.info(f"استخراج داده‌های رفتاری کاربر {mobile}...")

    try:
        # Use grep to extract lines with the mobile number
        result = subprocess.run(
            ['grep', f'^{mobile},', '/home/test/test/agent-club-research/demo_final/cleaned_score_view.csv'],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            logger.warning(f"خطا در اجرای grep: {result.stderr}")
            return pd.DataFrame()

        # Convert the grep output to a DataFrame
        from io import StringIO
        data = StringIO(result.stdout)
        df = pd.read_csv(data, header=None, names=['mobile', 'score', 'status', 'created_at_persian', 'title'])

        logger.info(f"تعداد {len(df)} رکورد رفتاری برای کاربر {mobile} یافت شد.")
        return df

    except Exception as e:
        logger.error(f"خطا در استخراج داده‌های رفتاری: {e}")
        return pd.DataFrame()

def get_behavior_summary(mobile: str) -> str:
    """Get a summarized view of user behavior history"""
    user_behavior = get_user_behavior_data(mobile)

    if user_behavior.empty:
        return "هیچ رفتاری برای این کاربر ثبت نشده است."

    # Count activities by title
    activity_counts = Counter(user_behavior['title'])

    # Calculate total scores by activity
    activity_scores = {}
    for _, row in user_behavior.iterrows():
        title = row['title']
        score = row['score']
        if title not in activity_scores:
            activity_scores[title] = 0
        activity_scores[title] += score

    # Get most recent activities
    sorted_behavior = user_behavior.sort_values('created_at_persian', ascending=False)
    recent_activities = sorted_behavior.head(5)

    # Get unique activity categories
    unique_activities = list(activity_counts.keys())

    # Create summary
    summary = f"خلاصه رفتار کاربر:\n"
    summary += f"- تعداد کل فعالیت‌ها: {len(user_behavior)}\n"
    summary += f"- تعداد انواع فعالیت‌ها: {len(unique_activities)}\n\n"

    summary += "تعداد فعالیت‌ها بر اساس نوع:\n"
    for activity, count in activity_counts.most_common():
        summary += f"- {activity}: {count} بار (مجموع امتیاز: {activity_scores[activity]})\n"

    summary += "\nآخرین فعالیت‌ها:\n"
    for _, rec in recent_activities.iterrows():
        summary += f"- {rec['created_at_persian']}: {rec['title']} (امتیاز: {rec['score']})\n"

    return summary

def get_behavior_by_category(mobile: str, category: str) -> str:
    """Get user behavior filtered by a specific category"""
    user_behavior = get_user_behavior_data(mobile)

    if user_behavior.empty:
        return "هیچ رفتاری برای این کاربر ثبت نشده است."

    # Filter records by category (if category is in the title)
    filtered_behavior = user_behavior[user_behavior['title'].str.contains(category, case=False, na=False)]

    if filtered_behavior.empty:
        return f"هیچ فعالیتی در دسته‌بندی '{category}' برای این کاربر یافت نشد."

    # Count activities
    activity_counts = Counter(filtered_behavior['title'])

    # Calculate total score
    total_score = filtered_behavior['score'].sum()

    # Get most recent activity
    most_recent = filtered_behavior.loc[filtered_behavior['created_at_persian'].idxmax()]

    # Create summary
    summary = f"خلاصه فعالیت‌های کاربر در دسته‌بندی '{category}':\n"
    summary += f"- تعداد کل فعالیت‌ها: {len(filtered_behavior)}\n"
    summary += f"- مجموع امتیاز: {total_score}\n"
    summary += f"- آخرین فعالیت: {most_recent['created_at_persian']} ({most_recent['title']})\n\n"

    summary += "تعداد فعالیت‌ها بر اساس نوع:\n"
    for activity, count in activity_counts.most_common():
        summary += f"- {activity}: {count} بار\n"

    return summary

# -----------------------------
# 3. New user categorization function
# -----------------------------
def categorize_user(mobile: str) -> str:
    """Categorize user based on behavior patterns"""
    logger.info(f"دسته‌بندی کاربر {mobile}...")

    user_behavior = get_user_behavior_data(mobile)

    if user_behavior.empty:
        return "کاربر یافت نشد"

    # Check if user is "کم اعتماد" (all points are غیرفعال)
    if all(status == 'غیرفعال' for status in user_behavior['status']):
        return "کم اعتماد"

    # Check if user is "اجتماعی" (has any of the specified behaviors)
    social_behaviors = ["ثبت درخواست 137", "نظرسنجی", "مسابقه", "دعوت از دوستان"]
    if any(any(behavior in title for behavior in social_behaviors) for title in user_behavior['title']):
        return "اجتماعی"

    # Check if user is "کاشف" (used more than 5 types of rewards)
    unique_rewards = len(set(user_behavior['title']))
    if unique_rewards > 5:
        return "کاشف"

    # Otherwise, user is "مالی"
    return "مالی"

# -----------------------------
# 4. Custom ZAI Model Implementation
# -----------------------------
class ZAIModel:
    def __init__(self, api_key: str, model_name: str = "glm-4.5-flash"):
        self.api_key = api_key
        self.model_name = model_name
        self.base_url = "https://open.bigmodel.cn/api/paas/v4"  # ZAI API endpoint
        logger.info(f"مدل ZAI با نام {model_name} آماده شد.")

    def chat_completions_create(self, messages, **kwargs):
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": self.model_name,
            "messages": messages,
            "stream": False
        }

        # Add optional parameters
        if "temperature" in kwargs:
            payload["temperature"] = kwargs["temperature"]
        if "max_tokens" in kwargs:
            payload["max_tokens"] = kwargs["max_tokens"]

        logger.info(f"ارسال درخواست به مدل ZAI...")
        response = requests.post(
            f"{self.base_url}/chat/completions",
            headers=headers,
            json=payload
        )

        if response.status_code != 200:
            logger.error(f"خطا در پاسخ از ZAI API: {response.status_code} - {response.text}")
            raise Exception(f"ZAI API Error: {response.status_code} - {response.text}")

        logger.info("پاسخ از مدل ZAI دریافت شد.")
        return response.json()

    def generate(self, system_prompt, user_message, tools=None):
        # Format messages for ZAI
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]

        response = self.chat_completions_create(messages)

        # Extract the content from the response
        if "choices" in response and len(response["choices"]) > 0:
            return response["choices"][0]["message"]["content"]
        else:
            logger.error("پاسخ نامعتبر از ZAI API دریافت شد.")
            raise Exception("Invalid response from ZAI API")

# -----------------------------
# 5. Tool Decision Function
# -----------------------------
def decide_tool(query, tools_info):
    """
    Use the model to decide which tool to use based on the query
    """
    system_prompt = f"""
    You are a tool selection assistant. Your job is to decide which tool to use for a given user query.

    Available tools:
    {tools_info}

    For the user query, decide which tool to use or if no tool is needed.
    Respond with just the tool name or "none" if no tool is needed.
    """

    # Create a temporary model instance for tool decision
    temp_model = ZAIModel(api_key="ebb378fb1657450583f64e6d0e94636b.5c66cIYnwtcNRNRL")

    # Get the decision from the model
    decision = temp_model.generate(
        system_prompt=system_prompt,
        user_message=query
    ).strip().lower()

    # Extract the tool name from the decision
    if decision == "none":
        return None

    # Check if the decision matches any tool name
    for tool_name in [tool.split(":")[0].strip() for tool in tools_info.split("\n")]:
        if tool_name.lower() in decision:
            return tool_name

    return None

# -----------------------------
# 6. Tool Definitions
# -----------------------------
class Tool:
    def __init__(self, name, description, function):
        self.name = name
        self.description = description
        self.function = function

# Helper functions to create tool functions
def make_predict_award_activation(model):
    def predict_award_activation(mobile: str, award_name: str) -> str:
        logger.info(f"شروع پیش‌بینی فعال‌سازی جایزه برای کاربر: {mobile} و جایزه: {award_name}")

        # Get user data
        rfm = get_rfm_data(mobile)
        behavior_summary = get_behavior_summary(mobile)

        # Try to find a relevant category for the award
        category_keywords = {
            "اتوبوس": ["اتوبوس", "حمل و نقل", "ترابری"],
            "تاکسی": ["تاکسی", "حمل و نقل", "ترابری"],
            "مترو": ["مترو", "حمل و نقل", "ترابری"],
            "کتاب": ["کتاب", "فرهنگی", "آموزشی"],
            "خرید": ["خرید", "فروشگاه", "مال"],
            "رستوران": ["رستوران", "غذا", "پذیرایی"],
            "فیلم": ["فیلم", "سینما", "سرگرمی"],
            "ورزش": ["ورزش", "باشگاه", "سلامتی"]
        }

        relevant_category = None
        for category, keywords in category_keywords.items():
            if any(keyword in award_name.lower() for keyword in keywords):
                relevant_category = category
                break

        # If we found a relevant category, get behavior for that category
        category_behavior = ""
        if relevant_category:
            category_behavior = get_behavior_by_category(mobile, relevant_category)

        # Generate prediction
        prompt = f"""شما یک دستیار هوشمند برای پیش‌بینی فعال‌سازی جوایز هستید. داده‌های RFM و خلاصه رفتار کاربر به همراه نام جایزه جدید به شما داده شده است.

داده‌های RFM کاربر:
{rfm}

خلاصه رفتار کاربر:
{behavior_summary}

{category_behavior}

نام جایزه جدید: {award_name}

لطفاً بر اساس این اطلاعات، پیش‌بینی کنید که این کاربر چند بار و در چه بازه زمانی (مثلاً در هفته، ماه یا سال) این جایزه را فعال خواهد کرد.
در پیش‌بینی خود، به ویژه به رفتارهای مشابه با جایزه جدید توجه کنید. برای مثال، اگر جایزه جدید مربوط به حمل و نقل است،
به فعالیت‌های حمل و نقل قبلی کاربر توجه کنید.

پاسخ خود را به صورت یک جمله در فارسی ارائه دهید."""

        logger.info("ارسال درخواست به مدل برای پیش‌بینی فعال‌سازی جایزه...")
        response = model.generate(
            system_prompt="",
            user_message=prompt
        )
        logger.info("پاسخ پیش‌بینی دریافت شد.")
        return response
    return predict_award_activation

def make_summarize_and_suggest(model):
    def summarize_and_suggest(mobile: str) -> str:
        logger.info(f"شروع خلاصه‌سازی و پیشنهاد برای کاربر: {mobile}")

        # Get user data
        rfm = get_rfm_data(mobile)
        behavior_summary = get_behavior_summary(mobile)

        # Generate summary and suggestions
        prompt = f"""شما یک دستیار هوشمند برای تحلیل رفتار کاربران و پیشنهاد جوایز هستید. داده‌های RFM و خلاصه رفتار کاربر به شما داده شده است.

داده‌های RFM کاربر:
{rfm}

خلاصه رفتار کاربر:
{behavior_summary}

لطفاً:
1. خلاصه‌ای از رفتار کاربر ارائه دهید.
2. بر اساس رفتار کاربر، پیشنهاداتی برای جوایز جدید که ممکن است برای این کاربر جذاب باشد، ارائه دهید.
   - اگر کاربر فعالیت‌های حمل و نقل دارد، جوایز مرتبط با حمل و نقل پیشنهاد دهید.
   - اگر کاربر فعالیت‌های فرهنگی دارد، جوایز مرتبط با فرهنگ و هنر پیشنهاد دهید.
   - اگر کاربر فعالیت‌های خرید دارد، جوایز مرتبط با خرید و تخفیف پیشنهاد دهید.
   - و به همین ترتیب برای سایر دسته‌بندی‌ها.

پاسخ خود را به فارسی و در دو بخش جداگانه ارائه دهید."""

        logger.info("ارسال درخواست به مدل برای خلاصه‌سازی و پیشنهاد...")
        response = model.generate(
            system_prompt="",
            user_message=prompt
        )
        logger.info("پاسخ خلاصه‌سازی و پیشنهاد دریافت شد.")
        return response
    return summarize_and_suggest

# -----------------------------
# 7. Initialize ZAI agent
# -----------------------------
logger.info("آماده‌سازی مدل ZAI...")
zai_model = ZAIModel(api_key="ebb378fb1657450583f64e6d0e94636b.5c66cIYnwtcNRNRL")

# Create tool functions
predict_func = make_predict_award_activation(zai_model)
suggest_func = make_summarize_and_suggest(zai_model)

class ZAIAgent:
    def __init__(self, model, system_prompt, tools=None):
        self.model = model
        self.system_prompt = system_prompt
        self.tools = tools or {}
        self.tool_functions = {tool.name: tool.function for tool in tools} if tools else {}
        self.tools_info = "\n".join([f"{tool.name}: {tool.description}" for tool in tools]) if tools else ""
        logger.info(f"عامل ZAI با {len(tools) if tools else 0} ابزار آماده شد.")

    def run_sync(self, query):
        logger.info(f"پرسش جدید دریافت شد: {query}")

        # Handle identity question
        if "شما چه هستید" in query or "چرا ایجاد شده‌اید" in query:
            logger.info("پاسخ به سوال هویتی")
            class Result:
                def __init__(self, content, tool_used=""):
                    self.content = content
                    self.tool_used = tool_used
            return Result("من یک دستیار هوشمند هستم که بر اساس داده های باشگاه شهروندی نرم افزار شهرمن مشهد توسعه پیدا کرده ام تا بتوانم سوالات شما را در خصوص رفتار کاربران و پیشنهاد مشوق های شهروندی پاسخ دهم", "")

        # Decide which tool to use
        tool_to_use = decide_tool(query, self.tools_info)
        tool_result = None
        tool_used = ""

        if tool_to_use and tool_to_use in self.tool_functions:
            logger.info(f"استفاده از ابزار: {tool_to_use}")
            if tool_to_use == "predict_award_activation":
                # Extract mobile and award name from query
                mobile_match = re.search(r'09\d{9}', query)
                if mobile_match:
                    mobile = mobile_match.group(0)
                    # Extract award name
                    award_name = query.replace(mobile, '').strip()
                    common_words = ["پیش‌بینی", "برای", "جایزه", "چند", "بار", "در", "چه", "بازه", "زمانی", "فعال", "می‌کند", "کاربر", "این", "که", "لطفاً", "؟"]
                    for word in common_words:
                        award_name = award_name.replace(word, '')
                    award_name = award_name.strip()
                    
                    if not award_name:
                        award_name = "جایزه جدید"
                    
                    tool_result = self.tool_functions[tool_to_use](mobile, award_name)
                    tool_used = tool_to_use
                else:
                    logger.warning("شماره موبایل در سوال یافت نشد.")
                    tool_result = "شماره موبایل در سوال یافت نشد."
            elif tool_to_use == "summarize_and_suggest":
                # Extract mobile from query
                mobile_match = re.search(r'09\d{9}', query)
                if mobile_match:
                    mobile = mobile_match.group(0)
                    tool_result = self.tool_functions[tool_to_use](mobile)
                    tool_used = tool_to_use
                else:
                    logger.warning("شماره موبایل در سوال یافت نشد.")
                    tool_result = "شماره موبایل در سوال یافت نشد."
            elif tool_to_use == "categorize_user":
                # Extract mobile from query
                mobile_match = re.search(r'09\d{9}', query)
                if mobile_match:
                    mobile = mobile_match.group(0)
                    tool_result = self.tool_functions[tool_to_use](mobile)
                    tool_used = tool_to_use
                else:
                    logger.warning("شماره موبایل در سوال یافت نشد.")
                    tool_result = "شماره موبایل در سوال یافت نشد."
        else:
            logger.info("هیچ ابزاری انتخاب نشد، پاسخ مستقیم از مدل")
            response = self.model.generate(
                system_prompt=self.system_prompt,
                user_message=query
            )
            class Result:
                def __init__(self, content, tool_used=""):
                    self.content = content
                    self.tool_used = tool_used
            return Result(response, "")

        # If we used a tool, incorporate the result
        if tool_result:
            # Create a user message that includes the tool result
            user_message = f"""
            User query: {query}

            Information from {tool_used} tool: {tool_result}

            Please provide a helpful response based on this information.
            """

            # Generate response using ZAI with the enhanced user message
            response = self.model.generate(
                system_prompt=self.system_prompt,
                user_message=user_message
            )
        else:
            # No tool used, just generate a response
            response = self.model.generate(
                system_prompt=self.system_prompt,
                user_message=query
            )

        # Create a result object similar to Pydantic AI's result
        class Result:
            def __init__(self, content, tool_used=""):
                self.content = content
                self.tool_used = tool_used

        return Result(response, tool_used)

logger.info("آماده‌سازی عامل هوشمند...")
agent = ZAIAgent(
    model=zai_model,
    system_prompt=(
        "شما یک دستیار هوشمند برای تحلیل رفتار کاربران باشگاه شهروندی هستید. "
        "شما سه ابزار اصلی دارید: یکی برای پیش‌بینی فعال‌سازی جوایز، دیگری برای خلاصه‌سازی رفتار و پیشنهاد جوایز، "
        "و سومی برای دسته‌بندی کاربران. لطفاً بر اساس سوال کاربر، ابزار مناسب را انتخاب کنید. "
        "اگر سوال کاربر شامل شماره موبایل و نام جایزه باشد، از ابزار predict_award_activation استفاده کنید. "
        "اگر فقط شماره موبایل داده شده باشد و درخواست خلاصه رفتار و پیشنهاد جوایز شده، از ابزار summarize_and_suggest استفاده کنید. "
        "اگر فقط شماره موبایل داده شده باشد و درخواست دسته‌بندی کاربر شده، از ابزار categorize_user استفاده کنید. "
        "همیشه به فارسی پاسخ دهید."
    ),
    tools=[
        Tool(
            name="predict_award_activation",
            description="برای پیش‌بینی تعداد دفعات فعال‌سازی یک جایزه جدید توسط کاربر. این ابزار نیاز به شماره موبایل کاربر و نام جایزه دارد.",
            function=predict_func
        ),
        Tool(
            name="summarize_and_suggest",
            description="برای خلاصه‌سازی رفتار کاربر و پیشنهاد جوایز جدید. این ابزار فقط به شماره موبایل کاربر نیاز دارد.",
            function=suggest_func
        ),
        Tool(
            name="categorize_user",
            description="برای دسته‌بندی کاربر در یکی از دسته‌های اجتماعی، کاشف، کم اعتماد یا مالی. این ابزار فقط به شماره موبایل کاربر نیاز دارد.",
            function=categorize_user
        )
    ]
)
logger.info("عامل هوشمند با موفقیت آماده شد.")
