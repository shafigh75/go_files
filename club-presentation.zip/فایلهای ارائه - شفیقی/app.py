from flask import Flask, render_template, request, jsonify
import logging
from generalAgent import agent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        user_message = data.get('message', '')

        if not user_message:
            return jsonify({'error': 'پیام خالی است'}), 400

        # Handle identity question
        if "شما چه هستید" in user_message or "چرا ایجاد شده‌اید" in user_message:
            logger.info("پاسخ به سوال هویتی")
            return jsonify({
                'response': "من یک دستیار هوشمند هستم که بر اساس داده های باشگاه شهروندی نرم افزار شهرمن مشهد توسعه پیدا کرده ام تا بتوانم سوالات شما را در خصوص رفتار کاربران و پیشنهاد مشوق های شهروندی پاسخ دهم",
                'tool_used': ""
            })

        # Get response from agent
        result = agent.run_sync(user_message)
        
        # Extract tool used from result
        tool_used = ""
        if hasattr(result, 'tool_name'):
            tool_used = result.tool_name

        return jsonify({
            'response': result.content,
            'tool_used': tool_used
        })
    except Exception as e:
        logger.error(f"خطا در پردازش درخواست چت: {e}")
        return jsonify({'error': 'خطا در پردازش درخواست'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
