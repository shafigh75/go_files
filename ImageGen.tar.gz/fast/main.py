from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import requests
import os

app = FastAPI()

# Mount the static directory to serve the generated image.
app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

def generate_image(prompt: str) -> bool:
    url = "https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-dev"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
    }
    payload = {"inputs": prompt}

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        # Ensure the static directory exists.
        os.makedirs("static", exist_ok=True)
        # Save the image to the static folder
        with open("static/img.png", "wb") as out_file:
            out_file.write(response.content)
        return True
    else:
        print("Error:", response.status_code, response.text)
        return False

@app.get("/", response_class=HTMLResponse)
async def form_get(request: Request):
    # Render the form with no image by default.
    return templates.TemplateResponse("index.html", {"request": request, "image": None, "error": None})

@app.post("/", response_class=HTMLResponse)
async def form_post(request: Request, prompt: str = Form(...)):
    success = generate_image(prompt)
    if success:
        # Use the static path for the generated image.
        image_url = "/static/img.png"
        return templates.TemplateResponse("index.html", {"request": request, "image": image_url, "error": None})
    else:
        error_message = "Failed to generate image. Please try again."
        return templates.TemplateResponse("index.html", {"request": request, "image": None, "error": error_message})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="5.252.216.154", port=8000, log_level="info")

